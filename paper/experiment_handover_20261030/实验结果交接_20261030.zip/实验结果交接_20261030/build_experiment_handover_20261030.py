"""Read-only experiment synthesis; writes only an independent handover package."""
import csv, datetime, hashlib, json, re, shutil, statistics as S, zipfile
from pathlib import Path
from xml.etree import ElementTree as E

R=Path(__file__).resolve().parents[1]; O=R/'实验结果交接_20261030';O.mkdir(exist_ok=True)
SOURCES={}; TABLES=[]; chunks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def track(p):
 p=Path(p).resolve();SOURCES[str(p)]=sha(p);return p
def read(rel):
 p=track(R/rel);return json.loads(p.read_text())
def say(s):chunks.append(s+'\n')
def heading(s):say('## '+s)
def table(name,headers,rows):
 rows=[[str(v) for v in row] for row in rows]
 TABLES.append((name,headers,rows))
 lines=['| '+' | '.join(headers)+' |','| '+' | '.join('---' for _ in headers)+' |']
 for row in rows:lines.append('| '+' | '.join(v.replace('|','／').replace('\n',' ') for v in row)+' |')
 say('\n'.join(lines))
 with (O/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)
 say('')
def ms(values):return f'{100*S.mean(values):.2f} ± {100*S.stdev(values):.2f}'
def pct(x):return f'{100*x:.2f}'
def src(rel):say('结果源：`'+rel+'`。')

grid=read('results/endpoint_full_grid.json');end=read('results/available_results.json')
rob=read('results/E2-C_results.json');shared=read('results/E1-D_matched1gpu_three_run_analysis_20261029.json')
res=read('results/E2-D_shared_resnet_audit.json');four=read('results/E2-E_four_epoch_resnet_audit_20261029.json')
conf=read('results/E4-B_robust_confidence.json');loco=read('results/E6-B_results.json')
lat=read('results/H200_latency_audit.json');local=read('deployment/completion.json')
factorial=read('E6-C3_factorial/results.json');integ=read('E7_promise_scheduler_20261029/real_endpoint_integration.json')
timing=read('E7_promise_scheduler_20261029/within_jvm_timing/results.json')
e8=read('E8_low_label_shared_20261029/shared_resnet_results.json')
base=read('results/E1-D_base_ATP_audit_20261029.json');basev=read('results/E1-D_base_ATP_tool_vocab_v2_audit_20261029.json')
cross=read('results/E1-D_matched_cross_family_20261029.json')
assert shared['complete'] and len(shared['all'])==12 and e8['complete']
assert grid['models']==48 and len(grid['records'])==96 and not rob['pending']

say('# 新增实验结果与证据交接说明（供论文修改 agent 使用）')
say('整理日期：2026-10-30。稿件：SMEJMS-D-26-02210。本文是一份内部实验说明，不是论文正文、摘要或审稿回复，不应整段照搬进稿件。')
say('用户已决定自行委托另一 agent 修改论文。本次工作只整理实验，不再改动任何论文 Word。论文底稿应由用户指定；9月5日投稿版位于 `/home/agiuser/文档/论文/JMS_5Sep2026.docx`。先前多个 FINAL／TRACKED／CONSERVATIVE／SURGICAL 版本只是编辑产物，不能作为实验数字的权威来源。尤其最近精简稿中手填的部分表3数字与审计JSON不一致，且换表后旧图及下游文字可能尚未同步；请按本说明所列JSON/CSV重新核对，不从这些稿件复制数字。')
say('本说明中所有准确率、FPR、recall等比例均以百分数展示；均值±标准差为三个固定训练种子的样本标准差（ddof=1）。单次记录、分位数、AUROC等会单独标明。当前文件系统结果已冻结到交接包，清单记录SHA-256；这次整理不重新训练或推理。')
say('本机实验根目录：`'+str(R)+'`。本文中的相对路径均相对于该目录。压缩包包含本说明Word/Markdown、全部汇总CSV、关键结果JSON、协议/代码/配置及既有阶段报告；不包含大模型权重和完整数据集。')

heading('1. 先读结论与实验优先级')
say('最直接的正面证据是：在恢复的端盖任务和固定VLM训练配方中，配对Full/ROI监督有价值；在共享任务M2/M3等更新比较中，ROI误放行的三种子均值下降，同时伴随Finish召回下降。共享模型可以同时提供ATP和局部状态输出；实际Java适配层已消费这些证据并落实SOP依赖与请求绑定。')
say('已有结果没有证明VLM在固定二分类或共享任务上普遍优于强视觉模型。ResNet50在若干主要指标更强。公共视频先导也没有证明验证门控提高真实报警质量。E8低标签预算仅完成ResNet50，尚不能构成VLM数据效率优势。论文价值应由作者结合具体范围论证，不得把这些缺口写成已解决。')
table('01_审稿意见对应',['审稿意见','对应证据','已回答程度','主要边界'],[
 ['R1-1 表3不一致','指标定义、212/285源端盖重建、完整计数','新指标口径可核查；旧表原因未恢复','不能猜旧四零件表的正确值'],
 ['R1-2 标签与图8','四动作词表、545测试分布、可追溯混淆矩阵','标签及面板纠正有依据','新图8属于新checkpoint，不能冒充旧矩阵复现'],
 ['R1-3 精度与硬件延迟','BF16声明、H200/4090视觉组件、Java CPU计时','组件精度和延迟有实测','不是完整视觉监控端到端延迟'],
 ['R2-1 创新/相关工作','等更新ROI对照、共享任务、执行接口','可支撑具体配置价值','文献论证仍需作者；单个VLM/ROI/FSM非新算法'],
 ['R2-2 外部基线/动机','ResNet18/50、CLIP、共享ResNet50、基础VLM、LOCO','已提供强对照与不利结果','不能声称所有精度优于视觉方法'],
 ['R2-3 FSM与报警','Java约束/真实预测集成/G-only回放/Assembly101','实现职责有证据；真实报警收益未闭合','缺原连续正常异常视频、状态真值与可见起点'],
 ['R2-4 统计','三种子、分母、无效输出、配对检验与完整对照','固定数据上的复现性增强','图像相关性与独立录像泛化仍未解决']])

heading('2. 数据恢复、ROI、标签与统计口径')
say('715条端盖原始图片/标注记录不等于715张独立实验图片。2.3来源212张用于训练；3.16来源285张用于测试；历史3.14来源218张中212张与训练图重复，另外6张独有图未纳入本次训练或验证。采用方案A保留212/285边界，取消3.14独立验证用途，不用该重合来源选epoch、prompt或checkpoint。')
say('端盖训练类别为88 Finish、124 Unfinish；测试141 Finish、144 Unfinish。Full/ROI是同源图像的两种观察。测试来源在旧研究中已使用过，不能称全新盲测集。字节/像素重复的处理不能证明录像独立、近重复消失或真实跨会话泛化。')
say('ROI保留训练2.3与测试3.16各自原框，按原论文长边10%规则扩边、边界裁剪、非负坐标向零取整，另存无损RGB PNG；使用已知标注框，不是自动检测器性能实验。历史3.14不同框单独保留，不自动判其错误。原稿历史最终运行ROI参数尚未恢复，不能把新裁剪视为旧运行逐像素复现。')
say('ATP使用1,709训练源、545测试源；四动作测试数Place=162、Install=36、Insert=200、Tighten=147。Capscrew插入标签为Insert。训练词表为4动作、3工具、7零件；测试动作/零件/工具组合均在训练组合中出现，当前任务不验证未见组合泛化。')
say('Finish为阳性：TP=完成预测完成，TN=未完成预测未完成，FP=未完成预测完成（误放行），FN=完成预测未完成。Accuracy=(TP+TN)/285；FPR=FP/144；Finish recall=TP/141；正确Unfinish率=TN/144。invalid保留在类别总分母并计为错误，不能悄悄删除；因此FPR+TN/144+invalid_Unfinish/144=1。原表3不互补不能仅凭这一机制推断旧运行根因。')
say('状态正确、零件正确与part+status joint正确要区分；ATP joint要求action、tool、part同时正确。主表端盖accuracy是状态二分类，不自动等于joint。Full/ROI、七种扰动、三种子和6840集成决策都重复使用源图，不能合并成新的独立样本数。')
say('数据/协议源：`../E0-C/E0-C_report.md`、`../E1-AB/execution_protocol.md`、`../E1-AB/data/source_manifest.json`、`../E1-AB/data/roi_manifest.json`、`results/ATP_composition_coverage_20261029.json`。')

heading('3. E1-AB及重复：端盖单任务VLM；E2视觉基线完整对照')
say('四配方：Full-only与ROI-only每轮212实例；Mixed为每源Full+ROI，共424实例；Full×2为每源Full重复两次，共424实例。后两者实例呈现与更新预算相同，视觉token/FLOPs不保证相同。所有配方都评同285图的Full和ROI视图，不按得分选择测试视图。')
say('VLM为Qwen2.5-VL-7B-Instruct原生全参数SFT，BF16，固定4轮最终checkpoint，AdamW学习率2e-5、weight decay0.01、线性调度、3% warmup、clip norm1；目标global batch32。Full/ROI-only共28更新；Mixed/Full×2共56更新。默认处理器及答案+终止token损失，greedy单beam、最多128新token。最早seed42在H100 80GB执行；实际模型/环境及参数精度以runtime lock为准，不能回填为历史8H200配置。')
say('ResNet18/50使用ImageNet初始化，224×224双线性resize与ImageNet normalization，AdamW 1e-4、weight decay0.01、30轮cosine；CLIP为冻结ViT-B/32、512维L2归一化特征和训练linear head，AdamW 1e-3、30轮。视觉基线固定第30轮，不测试选优。各家族42/43/44均保留，预训练、分辨率、优化器与轮数不同，因此跨家族不是等计算量因果对比。')
rows=[]
for x in grid['summary']:
 vals=[]
 for metric in ['accuracy','FPR','recall']:
  for view in ['Full','ROI']:
   v=x['views'][view][metric];assert abs(v['mean']-S.mean(v['values']))<1e-10
   vals.append(ms(v['values']))
 rows.append([x['family'],x['group']]+vals)
table('02_端盖完整48模型汇总',['家族','训练','Full acc %','ROI acc %','Full FPR %','ROI FPR %','Full recall %','ROI recall %'],rows)
src('results/endpoint_full_grid.json')
say('解释：VLM Mixed的Full/ROI均值98.36/99.30%，高于Full-only的94.15/96.02%与ROI-only的97.31/97.43%。Full×2种子43出现全Finish退化，导致均值和SD很差；必须保留，不能将这列差异全解释为ROI机制。Mixed ResNet50 ROI为99.88±0.20%，高于VLM的99.30±0.35%；ResNet18为99.65±0.61%。')
say('ROI-only→Full视图变化下，VLM保持较高描述性分数，而部分视觉基线降低；这提示视图适配差异，但不能直接称背景鲁棒性或归因某种注意力机制。所有反向视图、Full×2和更强ROI列必须一并留存。')
table('03_端盖逐种子全部96视图',['家族','训练','seed','view','acc %','FPR %','recall %'],[[x['family'],x['group'],x['seed'],x['view'],pct(x['accuracy']),pct(x['FPR']),pct(x['recall'])] for x in grid['records']])

heading('4. E1-D/E2-D：共享ATP+完成状态任务（主要比较）')
say('M0=1709 ATP/轮；M1=ATP+212 Full完成样本=1921实例/轮；M2=ATP+212 Full重复两次=2133/轮；M3=ATP+212 Full及212 ROI=2133/轮。四轮VLM更新依次216/244/268/268。每模型测试545 ATP+285 Full+285 ROI=1115条输出。M0没有状态监督，其状态结果属于未监督诊断。')
say('主要VLM三种子必须使用一致单GPU的seed42/43/44：seed42路径MATCHED1GPU，seed43/44路径FOLLOWUP_1GPU。不能混用原两GPU seed42，不能把中断的部分运行视为完成种子。主VLM全参数4轮、BF16、global batch32；共享ResNet50主对照为30轮、一个backbone和action/tool/part/state四heads，按每样本已有字段平均loss。')
rows=[];per=[]
for fam,allruns in [('VLM',shared['all']),('ResNet50',res['all'])]:
 for group in ['M0','M1','M2','M3']:
  rr=sorted([x for x in allruns if x['group']==group],key=lambda x:x['seed']);assert [x['seed'] for x in rr]==[42,43,44]
  bank=[]
  for x in rr:
   m=x['metrics'] if fam=='VLM' else x['completion']['metrics']
   vals=([m['ATP']['field_accuracy'][k] for k in ['action','tool','part']]+[m['ATP']['joint_accuracy']] if fam=='VLM' else [m['ATP'][k] for k in ['action','tool','part','joint']])
   vals += [m[v]['accuracy'] for v in ['Full','ROI']]+[m[v]['FPR'] for v in ['Full','ROI']]+[m[v]['TP']/141 for v in ['Full','ROI']]
   bank.append(vals);per.append([fam,group,x['seed']]+[pct(v) for v in vals])
  rows.append([fam,group]+[ms([v[i] for v in bank]) for i in range(10)])
table('04_共享任务完整汇总',['模型','组','Action %','Tool %','Part %','ATP joint %','Full acc %','ROI acc %','Full FPR %','ROI FPR %','Full recall %','ROI recall %'],rows)
table('05_共享任务24模型逐种子',['模型','组','seed','Action %','Tool %','Part %','ATP joint %','Full acc %','ROI acc %','Full FPR %','ROI FPR %','Full recall %','ROI recall %'],per)
src('results/E1-D_matched1gpu_three_run_analysis_20261029.json');src('results/E2-D_shared_resnet_audit.json')
say('VLM M2→M3：ATP joint 91.13±0.42→90.15±0.28%；Full state 93.92±1.07→96.37±2.94%；ROI state 94.27±0.41→97.43±2.34%。ROI FPR 11.34→0.46%，Finish recall 100→95.27%。不能只展示FPR下降，必须同报Finish拒绝增加与ATP小幅下降。共享ResNet50 M3为ATP 92.11±0.00%、Full 100%、ROI 99.88±0.20%，所以“共享任务能力”不是VLM独有优势。')
say('固定模型配对检验：完整54项McNemar做Holm54；以下保留M3−M2全部9项。ROI三种子中只有seed44在该家族校正后p<0.05；不能把平均分提高写成三种子全部显著。')
table('06_M2M3全部配对统计',['任务','seed','M3−M2 pp','M3独对/M2独对','Holm54 p'],[[x['task'],x['seed'],f"{100*x['difference']:.2f}",str(x['comparison_only_correct'])+'/'+str(x['reference_only_correct']),f"{x['p_holm_all54']:.6g}"] for x in shared['all54_contrasts'] if x['reference']=='M2' and x['comparison']=='M3'])

heading('5. 共享ResNet四轮补充与配置敏感性（次级证据）')
say('为检查30轮视觉训练与4轮VLM配方不同的影响，补做24个共享ResNet50：prefix30保留原30轮cosine的前4轮；cosine4在4轮完成cosine衰减。两日程全部组与种子均报告；原30轮强基线继续作为主要基线。这是看过前期结果后的补充，不是事先完全盲定；等源图/呈现/更新不等于等FLOPs或预训练。')
fr=[]
for schedule in ['prefix30','cosine4']:
 for group in ['M0','M1','M2','M3']:
  rr=[x['completion']['metrics'] for x in four['all'] if x['schedule']==schedule and x['group']==group];assert len(rr)==3
  vals=[[m['ATP']['joint'],m['Full']['accuracy'],m['ROI']['accuracy'],m['Full']['FPR'],m['ROI']['FPR']] for m in rr]
  fr.append([schedule,group]+[ms([r[i] for r in vals]) for i in range(5)])
table('07_四轮共享视觉基线',['日程','组','ATP joint %','Full acc %','ROI acc %','Full FPR %','ROI FPR %'],fr)
src('results/E2-E_four_epoch_resnet_audit_20261029.json')
say('原两GPU seed42与一致单GPU seed42的12个配置比较保留在 `results/E1-D_seed42_world_configuration_sensitivity_20261029.json`。差异包含归约与执行随机性，不能独立归因为GPU数量。完整跨家族36汇总/108逐模型对照保留在 `results/E1-D_matched_cross_family_20261029.json`，统一Holm108仅适用于该分析家族；不能与主54项当成全研究全局校正。')

heading('6. E2-C：对称ROI扰动')
say('只对Mixed训练模型施加同样7条件、各3种子：原框、左/右/上/下平移ROI宽或高10%、以中心缩放80%/120%。以扩边后的框为基准，裁边界后整数化。每模型285×7=1995次图像观察；12模型23940次观察仍只有285独立源图。不是自动ROI检测器实测，也不识别背景/尺度机制的独立因果效应。')
rr=[]
for family in ['vlm','resnet18','resnet50','clip']:
 models=sorted([x for x in rob['robustness'] if x['family']==family],key=lambda x:x['seed']);assert len(models)==3
 for cond in ['original','left10','right10','up10','down10','scale80','scale120']:
  m=[x['results'][cond] for x in models]
  rr.append([family,cond]+[ms([x[k] for x in m]) for k in ['accuracy','FPR','recall']])
table('08_ROI全部28条件汇总',['家族','条件','accuracy %','FPR %','Finish recall %'],rr)
src('results/E2-C_results.json')
say('应从全表描述条件相关的权衡，不能只挑某一个有利方向宣称全面鲁棒性领先。63项固定模型/条件/种子统计及区间位于 `results/E2-C_paired_statistics.json`；采用同源配对时仍须承认帧相关性。')

heading('7. E4-B：置信度诊断')
say('VLM置信度为包括终止token的生成token对数概率均值取exp；视觉分类器为softmax置信度，两种量未校准且语义不同。ECE为10等宽bin，另报Brier和正确性AUROC。以下每seed跨7条件等权，同源重复的1995个输出不能当独立录制。')
table('09_置信度全部12模型',['家族','seed','错误/1995','ECE10','Brier','正确性AUROC','错误平均置信度'],[[x['family'],x['seed'],x['metrics']['equal_weight_all_conditions']['errors'],*[f"{x['metrics']['equal_weight_all_conditions'][k]:.6f}" for k in ['ECE_10','Brier','AUROC_correctness','mean_error_confidence']]] for x in conf['all']])
say('三个VLM种子错误平均置信度约0.989；大部分输出都在最高bin。高准确率下ECE低并不意味着置信度可当物理完成概率，也不等于置信度加权改善报警。不得写成当前0.6阈值经过独立校准。')
src('results/E4-B_robust_confidence.json')

heading('8. R1-3：H200与RTX4090视觉组件耗时')
say('batch=1，每视图150个固定源，10次warm-up；已知目标与ROI，包含图像读取/预处理、传输、推理、解析；排除检测器、摄像头、网络和FSM。VLM BF16，视觉基线FP32。云端设备实测为H200，不要按最初申请H100的称呼写硬件。不同设备不同时段、共享主机活动与缓存未完全隔离，不能作为严格硬件加速比。')
lt=[]
for x in lat['rows']:lt.append(['H200',x['family'],x['view'],x['precision'],x['n'],f"{1000*x['mean_seconds']:.2f}",f"{1000*x['p50_seconds']:.2f}",f"{1000*x['p95_seconds']:.2f}",f"{x['peak_allocated_bytes']/1024**3:.3f}"])
for v,x in local['results'].items():lt.append(['RTX4090','VLM',v,'BF16',x['calls'],f"{1000*x['mean_seconds']:.2f}",f"{1000*x['p50_seconds']:.2f}",f"{1000*x['p95_seconds']:.2f}",f"{x['peak_allocated_bytes']/1024**3:.3f}"])
table('10_视觉组件耗时',['设备','模型','view','精度','n','mean ms','P50 ms','P95 ms','peak alloc GiB'],lt)
say('RTX4090数值按completion.json直接换算：Full mean=1369.46ms，ROI mean=619.45ms。此前稿件中的1369.50/619.40为较粗舍入，交接CSV使用源值保留两位小数。分解耗时/token数见 `deployment/component_summary.json`；不能把generation-only测量和此处总组件时间混用。')
src('results/H200_latency_audit.json');src('deployment/completion.json')

heading('9. 基础VLM的ATP与端盖诊断')
say('ATP用未适配Qwen2.5-VL-7B、同545图与冻结共享prompt。严格完整JSON和仅完整外层code fence归一化分开；invalid进入分母。原共享prompt未列工具白名单，后验加词表是另一个prompt条件，必须披露而不能只报低分基线。')
br=[]
for name,x in [('原冻结ATP prompt',base),('后验加工具白名单',basev)]:
 for parser,m in x['metrics'].items():br.append([name,parser,f"{m['valid']}/{m['n']}",*[pct(m['field_accuracy'][k]) for k in ['action','tool','part']],pct(m['joint_accuracy']),m['duplicate_key_outputs']])
table('11_基础VLM_ATP',['prompt','parser','valid/n','action %','tool %','part %','joint %','重复key输出'],br)
say('端盖基础模型完整570视图输出和严格/宽松诊断见 `results/base_vlm_reaudit.json`、`results/base_vlm_lenient_diagnostic.json` 与 `../E1-AB`结果。原prompt工具0分不能单独推断模型没有工具视觉能力；上述后验词表条件显示接口依赖。基础ATP测得generation-only耗时不与第8节组件总耗时合并。')

heading('10. E6-B：MVTec LOCO外部静态任务')
say('数据仅为splicing_connectors一个产品类别；360正常训练、60正常验证、312测试（119正常、108逻辑异常、85结构异常）。所有方法同验证/测试；验证正常分数95%分位higher作为阈值，严格>阈值判异常。强PatchCore/CLIP记忆库用360训练参考，补做同3参考基线；VLM使用固定3训练参考与完整候选序列似然。ROI等于整图，只评Full。这是静态异常扩展，标签和原Finish/Unfinish含义不完全相同。')
lr=[]
for x in loco['results']:
 m=x['metrics'];a=m['all'];lr.append([x['name'],pct(a['AUROC']),pct(a['AP']),pct(m['logical_anomalies']['AUROC']),pct(m['structural_anomalies']['AUROC']),pct(a['normal_false_rejection']),pct(a['anomaly_miss']),pct(a['recall'])])
table('12_LOCO全部21运行',['模型','AUROC %','AP %','logical AUROC %','structural AUROC %','正常误拒 %','异常漏检 %','异常recall %'],lr)
say('主要结论：360参考PatchCore AUROC约85%，高于约63%–73%的本组VLM；3参考PatchCore约74%–75%，也不能支持VLM普遍外部优越。所有源任务checkpoint均保留，不能按LOCO测试得分选最佳源模型或参考图。')
src('results/E6-B_results.json')

heading('11. E6-C：Assembly101因果视频先导与诊断')
say('官方数据源 https://huggingface.co/datasets/cvml-nus/assembly101 ，只获取并使用声明的训练/验证/测试候选，不是完整Assembly101。主c13a先导用5训练录像确定词表、参考与最小图，1验证窗口、1异常测试窗口；1Hz每tick一次模型调用，模型是未适配基础VLM，动作/目标由自身历史选择，无未来帧及逐帧真值输入。不是原齿轮泵任务，也不是原Java实现的等价复现。')
say('四组：action_only（A）、weighted_action_only（A+C）、unit_gate（G）、weighted_gate（G+C）。A+C在看过初期结果后补做，重放A完全相同的冻结General查询，无新推理，必须注明事后诊断。3条原轨迹共1464次模型调用（每条307 test+181 val），四组分数保留；相同匹配规则，不按配置改GT。')
ar=[]
for x in factorial['all']:
 for s in x['scores']:
  delay=s.get('detected_delay_mean_sec')
  ar.append([x['variant'],s['split'],s['TP'],s['FP'],s['FN'],pct(s['precision']),pct(s['recall']),pct(s['F1']),'NA' if delay is None else f'{delay:.3f}'])
table('13_Assembly101四配置全部结果',['配置','split','TP','FP','FN','precision %','recall %','F1 %','仅检出延迟s'],ar)
say('Test动作组TP/FP/FN=2/20/4，门控组1/21/5；置信度单独加入均未改变对应计数。两次动作组检出标注起点延迟3.80/5.03s（均值4.42），门控检出12.80s；漏检4/5件必须同时保留。延迟以官方动作标注起点计，并非人工首次可见错误起点。没有独立完全正常执行，不能估计真实正常运行误报率；FP也不能简单当每小时误报。')
say('解析器仅移除完整外层JSON code fence再检验完整对象、键和值；不是从任意长文本抽答案。全部1464调用需要这种归一化，不能与内部严格JSON结果直接当同接口排名。')
say('官方动作区间替换感知输入的CPU诊断：test从2/20/4到1/0/5、val从0/4/3到1/0/2，检出延迟0.80s；test仅265/307 tick唯一覆盖，val167/181，其余保持invalid。该输入带官方动作信息，不是可部署模型或理论上界；同动作元组可出现在correct/mistake区间，不能据此推导动作结束画面一定清晰完成。')
say('更大范围官方事件派生连接记忆：保守排除操作中及实例歧义后，train1441、val975、test624可判定点全部是Finish，Unfinish=0。constant_Finish已经100%，G+V与G无差别，不能形成有效完成/未完成对照。人工盲审包已生成，但没有完成独立人工可见状态审核；不能把派生动作标签或模型预测当审核真值。')
src('E6-C3_factorial/results.json');say('详见 `E6-C5_action_oracle/诊断报告.md`、`E6-E_blind_connection_20261029/official_event_derived_report.md`、`E6-C4_frozen_output_diagnostic/诊断报告.md`。')

heading('12. E6-D：原数据9阶段上下文、真实Java回放及噪声')
say('这批545 ATP保留图带两个序列索引及帧号，但不是完整连续录像。由于四颗螺钉共享ATP类别，无法从类别输出确定实例，把步骤1–7单列、8–11合并插入、12–15合并紧固，评9阶段。训练保留采样数构造人工配额/时钟；不能把采样图数当实测秒，也不能由文件帧号自行假定FPS。')
say('有两类独立方法：因果上下文过滤器（epsilon0.1/0.01、仅时长先验、future-dependent Viterbi参考）和实际合作者Java核心G-only回放（unit confidence、Verification关闭）。前者不是实际Java。两类均不验证15实例螺钉计数、完成状态门控或真实异常报警。所有24模型、两种epsilon和噪声条件保留。')
for title,rel in [('12.1 因果上下文完整表','E6-D_matched_phase_replay_20261029/结果报告.md'),('12.2 实际Java G-only完整表','E6-D3_java_matched_replay_20261029/结果报告.md'),('12.3 额外扰动完整表','E6-D_matched_phase_noise_sensitivity_20261029/结果报告.md')]:
 say('### '+title);say(track(R/rel).read_text())
say('追加扰动为0/5/10/20/30%，非零率各30个噪声seed，先对噪声重复取平均，再跨3个固定训练模型计算SD；0%不人为复制30次。扰动不读GT且有可能偶然纠正模型错误。噪声seed不增加独立录像数，额外扰动率不等于最终错误率。')
say('Java raw done可能在尚有未done前驱时出现；这是软核心语义，不可直接称作真实标注误放行率。新增E7硬admitted管理与core_done要严格区分。')

heading('13. E7：围绕SOP、G/V调度和局部证据使用的实际Java补充')
say('用新增PromiseScheduler.java适配层链接合作者原fsm-cli.jar，核心SHA256=20a3cd9ffc7ec9b84035cd6d2c58c62529b6d476bb4ef34533e1c3d634bebaa7。新增硬准入、请求ID/模式/节点/条件绑定、模式选择与报警差分属于返修实现，不能追溯为原CLI已具备。')
say('用户确认的15步SOP：1–7顺序；7之后8–11并列任意顺序；12–15同样任意顺序，但每个必须等8–11全完成。每步的验证需求另外配置；节点序号不提供真实螺钉身份。规则/fixture均给唯一合成身份和配额。')
say('全部576=4!×4!合法排列、60个不完整插入集合的提前紧固检查通过；独立逐命令审核11174条转换。另27条报警/非法输入套件检查unfinished、ordering、累计配额timeout、去重/解除/重置截尾、非法时间/缺失越界confidence/非法V值。未验证handling_timeout和真实异常现场表现。')
say('G→V→G、Finish/Unfinish/Unknown、0.6阈值边界、错目标/错模式、旧/重复响应拒收、重复动作、reset均有可追溯轨迹。Unfinish/Unknown重试会阻塞后续G；核心保留越序累积证据并可能包含跨V时段累积，正向确认锁存且无返工撤销。硬admitted约束不消除这些核心语义。EOF活跃报警由离线审核器记open_at_end，不能写Java已有结束会话API。')
say('条件静态集成：12个共享VLM checkpoint ×285图×2view=6840次决策。每图独立初始化一个合成action-ready端盖节点，只把严格模型预测喂给Java；GT只在独立scorer。此处放行/阻挡完全继承感知输出，不新增独立分类样本或FSM报警收益。')
ir=[]
for group in ['M0','M1','M2','M3']:
 for view in ['Full','ROI']:
  rr=[integ['groups'][f'{group}_s{s}_{view}'] for s in [42,43,44]]
  ir.append([group,view,'/'.join(str(x['false_release']) for x in rr),f"{100*S.mean(x['false_release']/144 for x in rr):.2f}",'/'.join(str(x['false_block']) for x in rr),f"{100*S.mean(1-x['false_block']/141 for x in rr):.2f}"])
table('14_Java条件静态集成全部视图',['组','view','各seed误放行/144','平均误放行%','各seed误阻挡/141','平均正确放行%'],ir)
say('M2/M3 ROI各seed误放行15/17/17→0/1/1；误阻挡0/0/0→4/14/2。平均FPR11.34→0.46%，正确放行100→95.27%。这些是模型感知差异传播到程序化决策的结果，不能归因为FSM使识别变强。')
src('E7_promise_scheduler_20261029/real_endpoint_integration.json')

heading('14. 两种Java CPU耗时的区别')
say('E6-D4仅计unchanged core的updateStateProbability：24输入bank、2 warm-up passes+10正式passes，130800正式调用，mean27.84µs、P50 20.34、P95 43.79、P99 65.60；不含输入解析、列表构造、初始化、目标选择、快照、报警管理和序列化。')
f=timing['formal'];table('15_Java完整调度CPU耗时',['范围','n','mean µs','P50 µs','P95 µs','P99 µs','max µs'],[['E7 accepted-response path',f['n'],*[f'{f[k]:.3f}' for k in ['mean_us','p50_us','p95_us','p99_us','max_us']]]])
say('E7正式计时同一JVM内2遍warm-up+5遍formal，包含JSON解析、校验、核心更新、准入、报警差分、下一请求、快照和主要序列化；排除视觉推理、网络、最终log framing/磁盘、进程启动。CPU为Intel Core Ultra7 265K、容器4逻辑CPU quota。首次“每遍新启JVM”计时保留为诊断，不能当已充分warm-up证据。P95按正式源值37.095µs；保留原始值避免37.09/37.10舍入争议。不能把本机CPU与云端GPU数直接相加冒充同硬件全链路。')
src('E7_promise_scheduler_20261029/within_jvm_timing/results.json')

heading('15. IndustReal恢复、官方PSR和稀疏视觉补充')
say('官方项目 https://github.com/TimSchoonbeek/IndustReal 。并未下载完整数据集/完整录像，仅恢复两段可用RGB切片及相关标注/检测器记录。最初下载失败不表示后来完全没有数据；随后已完成官方流程回放与稀疏视觉诊断。来源和恢复路径保留在协议及intake脚本；不能把第三方恢复资产称完整官方benchmark。')
for rel in ['E6-G_industreal_visual_20261029/report.md','E6-G_industreal_visual_20261029/report_format_normalized.md','E6-G_industreal_visual_20261029/downstream_psr_report_format_normalized.md']:
 say('### '+Path(rel).name);say(track(R/rel).read_text())
say('上述严格解析主结果与事后仅剥完整外层code fence诊断必须分开。2829查询、123采样帧；非二进制GT条目独立保留。detector_reference与VLM训练背景不同。48次官方下游回放里主对照条件分数相同，未显示稀疏V替换改善PSR；官方system TP/FP/FN是步骤识别且含提前预测惩罚，不能重命名为原FSM错误报警P/R/F1。')

heading('16. E8：低完成标签预算（最新，尚未纳入10月29日清稿）')
say('仅共享ResNet50阶段已完成：固定全部1709 ATP训练源；完成标签使用严格嵌套、类别分层的53/106/212源预算；各预算M2重复Full与M3 Full+ROI的源图/呈现数/更新数相同，seeds42/43/44，固定30轮最终模型。25/50%共12个新增模型及13380预测，100%复用E2-D六个M2/M3模型，不重算成新增训练。')
er=[]
for x in e8['summary']:
 er.append([x['endpoint_sources'],x['group']]+[f"{100*x[k+'_mean']:.2f} ± {100*x[k+'_sample_sd']:.2f}" for k in ['ATP_joint','Full_accuracy','ROI_accuracy','ROI_FPR','ROI_recall']])
table('16_E8标签预算全部汇总',['源数','组','ATP joint %','Full acc %','ROI acc %','ROI FPR %','ROI recall %'],er)
say('支持的结论：当前共享视觉backbone同样受益于匹配ROI监督，25%预算已在当前测试集接近/达到饱和；只是增加Full标签不能替代ROI观察。不能声称VLM数据效率优于ResNet，不能说53张是最小充分标注量，不能由这张表推出跨产品泛化。对应VLM低预算运行未完成；没有新增可报告的VLM E8结果。')
src('E8_low_label_shared_20261029/shared_resnet_results.json')

heading('17. 统计解释、旧结果以及写作时需要避免的混淆')
say('所有新结果是恢复数据上的重建/补充，不是丢失旧checkpoint的完全复现。旧四零件112源/224 view及519训练源的结果、历史guided prompt、检测cascade、YOLO few-shot等缺原预测时，不能用本轮285端盖任务数字冒充纠正。历史结论如何保留或限定由作者与修改agent决定，但不能把未经核实数字标为新实验。')
say('不利结果也已交接：端盖Full×2退化；ResNet50更高固定任务精度；共享任务ATP权衡；LOCO PatchCore占优；公共FSM门控没有收益；事件派生标签单一；稀疏IndustReal没有有效下游改进。选择文章篇幅可以按论证相关性安排正文/补充，但不能通过删掉强基线或不利条件制造优越性。')
say('配对bootstrap条件于固定模型与源图可交换假设，不能解释为对新录像或训练随机性的区间。54/108/63/36是不同披露的分析家族，不是全项目全局多重校正；不要笼统写“所有p均已全局校正”。零FP/144不等于零风险，条件Wilson95%上界约2.60%。')
say('图8新图位于 `提交终稿_20261029/Figure8_audited_M3_seed42.png` 和 `Figure8_counts.json`，固定一致单GPU M3 seed42，在545测试上生成；面板(a)Part/(b)Action/(c)Tool。其他三种子及组完整结果仍以共享任务JSON为准。原SOP新图为 `Figure4_author_confirmed_SOP.png`，图中ALL8–11依赖符合作者确认；换图不能省略相应实现/范围说明。')

heading('18. 给修改agent的工作边界与阅读顺序')
say('1）先读本说明1–4节及审稿意见映射，再决定哪些实验进入正文；不要从旧修改稿复制措辞或表格。用户要求尽量少改原文，由用户/修改agent负责取舍；本交接不规定必须重写章节。')
say('2）若主张局部监督，用端盖Full/ROI四配方和共享任务M2/M3；若主张程序化使用，用E7；若讨论真实报警，明确Assembly101先导现有结果与缺口。三个层次的结论不要互相替代。')
say('3）数字优先从配套CSV/关键JSON取得；生成脚本、源路径和SHA清单提供核对。核对状态准确率/Joint、百分数/比例、µs/ms/s、训练seed/噪声seed/录像样本数。')
say('4）当前仍缺：原任务完整正常异常录像、可靠独立完成真值/首次可见异常起点、实际螺钉实例识别与返工状态、完整端到端监控延迟、VLM低标签预算曲线。不能把计划当结果。')
say('5）截至本交接，没有为论文写新摘要或新结论，也没有将E8自动加入现有正文。此前10月29日广泛重写清稿包含E7及大部分诊断但不含E8；最近“精简稿”编辑链存在不一致，因此交接不对任一旧稿件作投稿就绪认证。')

# Human-readable result locator, copied reports and numerical sources.
reports=[
 'results/端盖完整训练视图比较.md','results/端盖配方配对诊断.md','results/端盖视图变化诊断.md',
 'results/E1-D_一致单卡共享VLM三次重复完整统计_20261029.md','results/E1-D_matched_cross_family_20261029.md',
 'results/E2-E_四轮共享基线完整结果_20261029.md','results/E2-E_四轮基线结果解读_20261029.md',
 'results/E4-B_扰动置信度诊断.md','results/E6-B_滚动结果.md','results/E6-C3_FSM四格诊断.md',
 'E6-C1_完成报告.md','E6-C5_action_oracle/诊断报告.md','E6-C4_frozen_output_diagnostic/诊断报告.md',
 'E6-E_blind_connection_20261029/official_event_derived_report.md',
 'E6-D_matched_phase_replay_20261029/结果报告.md','E6-D3_java_matched_replay_20261029/结果报告.md',
 'E6-D_matched_phase_noise_sensitivity_20261029/结果报告.md','E6-D4_java_state_update_timing_20261029/结果报告.md',
 'E7_promise_scheduler_20261029/完成报告_论文承诺对应.md',
 'E6-G_industreal_visual_20261029/report.md','E6-G_industreal_visual_20261029/report_format_normalized.md',
 'E6-G_industreal_visual_20261029/downstream_psr_report.md','E6-G_industreal_visual_20261029/downstream_psr_report_format_normalized.md',
 'E8_low_label_shared_20261029/阶段报告_共享ResNet50.md',
 '../E0-C/E0-C_report.md','../E1-AB/execution_protocol.md','../E1-AB/E1-AB_report.md']
extra=[
 'results/endpoint_paired_analysis.json','results/endpoint_view_shift_diagnostic.json','results/E2-C_paired_statistics.json',
 'results/E1-D_seed42_world_configuration_sensitivity_20261029.json','results/ATP_composition_coverage_20261029.json',
 'results/base_vlm_reaudit.json','results/base_vlm_lenient_diagnostic.json','results/SOP_author_confirmed_parallel_barrier_20261029.json',
 'E6-D_matched_phase_replay_20261029/results.json','E6-D_matched_phase_replay_20261029/independent_scoring_audit.json',
 'E6-D3_java_matched_replay_20261029/results.json','E6-D3_java_matched_replay_20261029/independent_audit.json',
 'E6-D_matched_phase_noise_sensitivity_20261029/results.json','E6-D_matched_phase_noise_sensitivity_20261029/independent_aggregation_audit.json',
 'E6-D4_java_state_update_timing_20261029/results.json','E6-C5_action_oracle/results.json',
 'E7_promise_scheduler_20261029/independent_trace_audit.json','E7_promise_scheduler_20261029/final_audited_status.json',
 'E7_promise_scheduler_20261029/author_graph.sop.json','E7_promise_scheduler_20261029/prediction_sources.json',
 'E7_promise_scheduler_20261029/alarm_extension/audit.json',
 'E6-G_industreal_visual_20261029/results_summary.json','E6-G_industreal_visual_20261029/results_summary_format_normalized.json',
 'E6-G_industreal_visual_20261029/downstream_psr_results_format_normalized.json','E6-G_industreal_visual_20261029/independent_audit.json',
 'E6-F_industreal_official_replay_20261029/results.json','E8_low_label_shared_20261029/independent_audit.json',
 'E8_low_label_shared_20261029/protocol_before_results.json','E8_low_label_shared_20261029/subsets.json',
 'deployment/component_summary.json','deployment/environment.json','deployment/selection_before_measurement.json',
 '../E1-AB/config/runtime_lock.json','../E1-AB/config/approved_protocol.json','../E1-AB/config/prompt.txt',
 '../E1-AB/data/source_manifest.json','../E1-AB/data/roi_manifest.json',
 'cloud_mirror/E1-D_MATCHED1GPU_s42_M3_20261029/runs/M3/run_config.json',
 'scripts/resnet_baseline.py','scripts/clip_linear_baseline.py','scripts/joint_resnet.py',
 'scripts/joint_distributed_matched1gpu_s42.py','scripts/roi_robustness.py','scripts/shared_matched_cross_family.py',
 'scripts/run_promise_scheduler_20261029.py','scripts/score_industreal_v_20261029.py',
 'E7_promise_scheduler_20261029/PromiseScheduler.java',
 '提交终稿_20261029/Figure8_counts.json']
missing=[]
for rel in reports+extra:
 p=R/rel
 if p.is_file():track(p)
 else:missing.append(rel)

# Verify frozen model prediction inputs in the primary matched 12-model analysis.
prediction_checks=[]
for name,expected in shared['inputs'].items():
 p=Path(name);actual=sha(p) if p.exists() else None
 assert actual==expected,(name,actual,expected)
 n=sum(1 for line in p.open() if line.strip());assert n==1115
 prediction_checks.append(dict(path=name,sha256=actual,records=n,passed=True))
say('### 主共享任务本次交接复核')
say('12份主要共享VLM预测文件均在本次交接时重新计算SHA-256并与主分析输入清单一致，每份1115条，共13380条。汇总表均由现存结果JSON直接生成；本次没有重新执行GPU训练或独立复现全部模型。既有阶段审计与本次文件/汇总检查的范围应区分。')

heading('19. 结果文件索引')
table('17_关键证据文件索引',['结果/代码原始位置','交接包相对位置','SHA256'],[[str(p),('evidence/'+str(p.relative_to(R)) if p.is_relative_to(R) else 'evidence/prior_stages/'+str(p.relative_to(R.parent))),h] for n,h in sorted(SOURCES.items()) for p in [Path(n)]])
md=O/'新增实验结果详尽说明_供修改agent.md';md.write_text('\n'.join(chunks),encoding='utf-8')

# Copy evidence snapshots with relative hierarchy. No manuscripts, weights or dataset images.
for n in list(SOURCES):
 p=Path(n)
 rel=p.relative_to(R) if p.is_relative_to(R) else Path('prior_stages')/p.relative_to(R.parent)
 dest=O/'evidence'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
figures=list((R/'results/figures').glob('*.png'))+[R/'E8_low_label_shared_20261029/learning_curve_shared_resnet50.png',R/'提交终稿_20261029/Figure8_audited_M3_seed42.png',R/'提交终稿_20261029/Figure4_author_confirmed_SOP.png']
for p in figures:
 if p.is_file():
  dst=O/'figures'/p.name;dst.parent.mkdir(exist_ok=True);shutil.copy2(p,dst)

# Word export using minimal valid OOXML; this is an independent explanatory document.
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';E.register_namespace('w',W)
def tag(n):return '{'+W+'}'+n
doc=E.Element(tag('document'));body=E.SubElement(doc,tag('body'))
def paragraph(s,style=None):
 p=E.SubElement(body,tag('p'));pr=E.SubElement(p,tag('pPr'))
 if style:E.SubElement(pr,tag('pStyle'),{tag('val'):style})
 E.SubElement(pr,tag('spacing'),{tag('after'):'100',tag('line'):'270',tag('lineRule'):'auto'})
 r=E.SubElement(p,tag('r'));t=E.SubElement(r,tag('t'),{'{http://www.w3.org/XML/1998/namespace}space':'preserve'});t.text=s
def word_table(lines):
 parsed=[[x.strip() for x in ln.strip().strip('|').split('|')] for ln in lines]
 parsed=[row for row in parsed if not all(re.fullmatch(r':?-+:?',x or 'x') for x in row)]
 t=E.SubElement(body,tag('tbl'));pr=E.SubElement(t,tag('tblPr'))
 E.SubElement(pr,tag('tblW'),{tag('w'):'0',tag('type'):'auto'})
 borders=E.SubElement(pr,tag('tblBorders'))
 for side in ['top','left','bottom','right','insideH','insideV']:E.SubElement(borders,tag(side),{tag('val'):'single',tag('sz'):'4',tag('color'):'BBBBBB'})
 for ri,row in enumerate(parsed):
  tr=E.SubElement(t,tag('tr'));trpr=E.SubElement(tr,tag('trPr'));E.SubElement(trpr,tag('cantSplit'))
  if ri==0:E.SubElement(trpr,tag('tblHeader'))
  for val in row:
   tc=E.SubElement(tr,tag('tc'));p=E.SubElement(tc,tag('p'));r=E.SubElement(p,tag('r'));rp=E.SubElement(r,tag('rPr'));E.SubElement(rp,tag('sz'),{tag('val'):'16'})
   if ri==0:E.SubElement(rp,tag('b'))
   tt=E.SubElement(r,tag('t'));tt.text=val
lines=md.read_text().splitlines();i=0
while i<len(lines):
 line=lines[i]
 if line.startswith('|'):
  block=[]
  while i<len(lines) and lines[i].startswith('|'):block.append(lines[i]);i+=1
  word_table(block);continue
 if line.strip():
  m=re.match(r'^(#{1,3})\s+(.*)$',line)
  paragraph(m[2] if m else line,'Title' if m and len(m[1])==1 else 'Heading1' if m and len(m[1])==2 else 'Heading2' if m else None)
 i+=1
sect=E.SubElement(body,tag('sectPr'));E.SubElement(sect,tag('pgSz'),{tag('w'):'16838',tag('h'):'11906',tag('orient'):'landscape'})
E.SubElement(sect,tag('pgMar'),{tag('top'):'720',tag('bottom'):'720',tag('left'):'720',tag('right'):'720',tag('header'):'360',tag('footer'):'360'})
styles=E.Element(tag('styles'));defaults=E.SubElement(styles,tag('docDefaults'));rd=E.SubElement(defaults,tag('rPrDefault'));rp=E.SubElement(rd,tag('rPr'))
E.SubElement(rp,tag('rFonts'),{tag('ascii'):'Calibri',tag('hAnsi'):'Calibri',tag('eastAsia'):'Microsoft YaHei'});E.SubElement(rp,tag('sz'),{tag('val'):'20'})
for name,size in [('Normal',20),('Title',32),('Heading1',27),('Heading2',23)]:
 st=E.SubElement(styles,tag('style'),{tag('type'):'paragraph',tag('styleId'):name});E.SubElement(st,tag('name'),{tag('val'):name});r=E.SubElement(st,tag('rPr'));E.SubElement(r,tag('sz'),{tag('val'):str(size)})
 if name!='Normal':E.SubElement(r,tag('b'))
settings=E.Element(tag('settings'));E.SubElement(settings,tag('defaultTabStop'),{tag('val'):'720'})
parts={'word/document.xml':E.tostring(doc,encoding='utf-8',xml_declaration=True),'word/styles.xml':E.tostring(styles,encoding='utf-8',xml_declaration=True),'word/settings.xml':E.tostring(settings,encoding='utf-8',xml_declaration=True),
 '[Content_Types].xml':b'''<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/></Types>''',
 '_rels/.rels':b'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''',
 'word/_rels/document.xml.rels':b'''<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/></Relationships>'''}
word=O/'新增实验结果详尽说明_供修改agent.docx'
with zipfile.ZipFile(word,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for n,b in parts.items():E.fromstring(b);z.writestr(n,b)
readme=O/'先读我.md';readme.write_text('先读《新增实验结果详尽说明_供修改agent》Word或Markdown，再使用01—17 CSV核对数字。evidence保留关键结果、协议、代码和阶段报告；figures提供现有图。\n\n原始实验根目录：'+str(R)+'\n\n不包含模型权重和完整数据集；原预测文件的路径和SHA保留在关键JSON中。此次只整理实验，不修改论文。旧稿件表号不作为交接固定编号；最近编辑稿存在不一致，请勿直接拿来作数值依据。\n',encoding='utf-8')
shutil.copy2(Path(__file__),O/'build_experiment_handover_20261030.py')
snapshot={str(p.relative_to(O)):sha(p) for p in O.rglob('*') if p.is_file() and p.name not in ['交接包文件SHA256.json','交接核验.json']}
(O/'交接包文件SHA256.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
assert len(TABLES)==17
audit={'passed':True,'created_at':datetime.datetime.now().isoformat(),'source_count':len(SOURCES),'tables':len(TABLES),'markdown_characters':len(md.read_text()),'primary_prediction_checks':prediction_checks,'optional_source_files_not_found':missing,'manuscripts_modified':False,'new_training_or_inference':False,'scope':'Numbers generated from archived result JSON; primary12 prediction hashes/counts rechecked; other experiment numerical audits are supplied existing artifacts. OOXML package checked, no native Microsoft Word rendering verification.'}
(O/'交接核验.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
archive=O.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file():z.write(p,str(Path(O.name)/p.relative_to(O)))
 assert z.testzip() is None
desktop=Path('/home/agiuser/桌面');shutil.copy2(word,desktop/word.name);shutil.copy2(archive,desktop/archive.name)
print(json.dumps({k:v for k,v in audit.items() if k!='primary_prediction_checks'},ensure_ascii=False,indent=2));print('Word:',word);print('ZIP:',archive)
