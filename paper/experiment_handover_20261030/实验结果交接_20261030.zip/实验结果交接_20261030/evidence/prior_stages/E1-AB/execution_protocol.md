**E1-AB实际执行协议（训练、评测与统计已完成）**

当前结果见[E1-AB完成报告](E1-AB_report.md)。正式运行的最终证据在`cloud_mirror/`，完成状态见`validation_record.json`；`cloud_evidence/`与`results/execution_partial/`保留早期快照。本文件下文记录当时冻结并实际执行的协议。

批准依据：用户“我同意，开始实验”，覆盖E0-C的合并E1-AB卡。2026-10-27 13:52:56开始；15:00:39启动第一组正式训练。执行期间遵循整阶段审批，普通修复和已列技术重试不另问。

**已冻结的数据与比较。**

方案A：2.3的212源帧训练（Finish88/Unfinish124），3.16的285源帧测试（Finish141/Unfinish144）。没有独立验证；3.14不作选择。每个源图只由原来源框按长边10%扩边、裁到边界、非负坐标向零取整得到ROI。保存无损RGB PNG，497个新裁剪均与Pillow/Gdk解码的原JPEG相应区域逐像素相同；原图与标注未修改。

Full-only/ROI-only每轮212实例、4轮848实例、28更新；Mixed/Full-repeat2每轮424实例、4轮1696实例、56更新。Full-repeat2是相同Full重复两次，独立源图仍212。每个模型Full/ROI各评285，另有不做本任务SFT的基础模型对照，共2850条预测；统计独立性不按视图或模型倍增。

**已冻结的实现。**

Qwen/Qwen2.5-VL-7B-Instruct，revision cc594898137f460bfe9f0759e9844b3ce807cfb5，含视觉组件8292166656参数。原生全参数SFT，单H100 80GB；BF16权重、梯度与原生AdamW moments，无FP32 master copy。学习率2e-5，AdamW beta0.9/0.999、eps1e-8，weight decay0.01且bias/norm不衰减，grad norm1.0。此为所选实现的真实精度，不回填为历史8H200实现的证明。

seed/data seed42；每轮使用42+epoch的确定性顺序。microbatch1、目标累积32，epoch末尾按实际20或8实例归一，不丢样本。每实例对assistant答案及im_end取平均loss，再对本次更新实例取平均。标准Transformers线性warmup/decay；首个optimizer step的LR为0但推进Adam状态，28/56总步数与完整LR序列均在runtime lock中明示。

处理器使用模型保存的默认图像策略；图像处理器Qwen2VLImageProcessor，文本tokenizerQwen2TokenizerFast。Full/ROI共用同一Port End Cover提示；训练输入最长2766token，未截断。正式推理BF16、greedy、单beam、最多128新token。模型计时日志的generation_seconds不含预处理，不能代替端到端部署时延。

正式checkpoint只取完整4轮且覆盖/更新次数核验通过的最终模型。四组都从相同基础权重重置，技术短跑权重不进入正式结果；没有测试分数选优、早停或调参。

**短跑与技术修复证据。**

Native短跑4次更新已通过；全部参数有梯度，损失/梯度有限，保存重载全部参数hash相同，4个训练来源生成探针token相同。阶段GPU可行性用时约421.2秒（含4.1秒CUDA环境检查）；GPU峰值allocated约69.2GiB，reserved约73.6GiB。

软件核对发现显式use_fast=false同时改变了文本tokenizer实现。正式训练前恢复基础模型默认Fast文本tokenizer，针对全部994个视图逐项验证input_ids、attention_mask、pixel_values、image_grid_thw及训练labels完全相等，且与原预检查token hash相同；短跑输出decode也相同。没有增加训练更新或使用测试模型表现来修复。预启动lock v1保留为superseded；最终冻结版本为60cbe724672ea64ad5ef6ee9c5ad25f9062027cc8227aef631a1c3ae8bdf2cba。

**指标与解释边界。**

严格JSON主口径，全部invalid进分母；状态正确、part正确和joint分开。Full/ROI各自285条先报告，570只作配对描述汇总。保留旧式宽松解析诊断、所有错误和FP↔invalid/正确分类的配对转移。主对比预先指定为ROI输入上的Mixed vs Full-only FPR，同看recall、Accuracy、invalid和Joint。

只有一个训练seed；3.16是已有历史成绩的测试来源，不是新盲测；两个文件名短片族与类别混杂，独立录制未证实。新增结果是受控重建与补充，不自动覆盖原表或修改原结论。四零件、ATP、FSM/报警与4090部署不由本轮代替。

**资源与产物。**

现有H100单卡，总GPU上限24h（可行性上限2h），墙钟上限48h；所有GPU子进程受guard限制，含加载/保存墙钟保守记账。短跑后的全清单保守估算含25%余量为19.95h，正式启动时剩余23.88h。真实用量以evidence/gpu_usage.json为准，不以估算充当实耗。

官方模型约15.46GiB计费下载；5权重分片对官方LFS SHA256、9元数据文件对官方Git blob验证。公网出口不可用时通过SSH流式转发，模型不落本机整份；转发服务已关闭。数据/代码/裁剪上传单独核算，初次rsync约399.7MB；依赖下载0，隔离venv继承既有只读系统包。本机/云端存储上限分别10/250GiB。

主证据：approval_record.json、config/runtime_lock.json、data/*manifest.json、cloud_evidence/preflight.json、cloud_evidence/processor_equivalence.json、cloud_evidence/smoke_native.json、云端runs/*/completion.json及results/*/predictions.jsonl。全部结果完成后统一形成统计、图表、原稿差异解释与归档hash。
