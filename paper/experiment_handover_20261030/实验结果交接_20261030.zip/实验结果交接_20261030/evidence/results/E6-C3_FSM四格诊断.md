# FSM四格补充诊断

Four-factorial diagnostic on same one val/one test recording; weighted_action_only reuses identical frozen General queries. No new VLM inference, independent recordings, or type-specific alarm validation. Original1464 trajectories/scores reproduced exactly.

|划分|配置|TP|FP|FN|Precision%|Recall%|F1%|已检事件延迟s|
|---|---|---:|---:|---:|---:|---:|---:|---|
|test|action_only|2|20|4|9.09|33.33|14.29|[3.8000000000000114, 5.03333333333336]|
|val|action_only|0|4|3|0.00|0.00|0.00|[]|
|test|unit_gate|1|21|5|4.55|16.67|7.14|[12.800000000000011]|
|val|unit_gate|0|11|3|0.00|0.00|0.00|[]|
|test|weighted_gate|1|21|5|4.55|16.67|7.14|[12.800000000000011]|
|val|weighted_gate|0|11|3|0.00|0.00|0.00|[]|
|test|weighted_action_only|2|20|4|9.09|33.33|14.29|[3.8000000000000114, 5.03333333333336]|
|val|weighted_action_only|0|4|3|0.00|0.00|0.00|[]|

初始测试结果已经查看，本步属于探索性补充。原三组全部1464条轨迹与评分逐条一致；新增488次缓存状态重放，不增加模型推理调用或独立样本。保留每个漏报；正确片段内误报仍不能替代纯正常执行误报率。
