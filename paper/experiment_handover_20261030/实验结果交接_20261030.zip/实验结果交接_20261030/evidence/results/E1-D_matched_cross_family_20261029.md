# 一致单卡三种子与共享ResNet完整比较

Exploratory supplement with prior core/primary-baseline results known. All matched world1 VLM seeds42/43/44, all groups/tasks/views and all three ResNet schedules. Primary30 remains the strong baseline. M0 state heads are unsupervised diagnostics. Same seed indices do not imply shared initialization across architectures. Different pretraining/optimizers/resolutions/FLOPs: not an equal-compute architecture test. Source exchangeability is unverified; intervals condition on the three fixed models, not training randomness or independent recordings. All108 tests retained; Holm108 is this analysis family only, not a global adjustment over every study. No noon snapshot or Word overwrite.

|日程|组|任务|VLM %|ResNet50 %|差值pp|固定模型源图条件性95%区间pp|
|---|---|---|---:|---:|---:|---:|
|primary30|M0|ATP|89.66 ± 3.06|92.78 ± 0.64|-3.12|[-5.14, -1.16]|
|primary30|M1|ATP|91.07 ± 1.64|90.64 ± 3.06|0.43|[-1.28, 2.14]|
|primary30|M2|ATP|91.13 ± 0.42|94.37 ± 1.39|-3.24|[-5.02, -1.47]|
|primary30|M3|ATP|90.15 ± 0.28|92.11 ± 0.00|-1.96|[-4.04, 0.12]|
|prefix30|M0|ATP|89.66 ± 3.06|91.44 ± 1.06|-1.77|[-3.79, 0.31]|
|prefix30|M1|ATP|91.07 ± 1.64|89.91 ± 3.12|1.16|[-0.55, 2.81]|
|prefix30|M2|ATP|91.13 ± 0.42|90.34 ± 0.76|0.80|[-1.41, 2.94]|
|prefix30|M3|ATP|90.15 ± 0.28|91.93 ± 0.49|-1.77|[-3.85, 0.31]|
|cosine4|M0|ATP|89.66 ± 3.06|91.31 ± 1.04|-1.65|[-3.73, 0.37]|
|cosine4|M1|ATP|91.07 ± 1.64|89.48 ± 2.39|1.59|[-0.31, 3.49]|
|cosine4|M2|ATP|91.13 ± 0.42|91.31 ± 1.58|-0.18|[-2.20, 1.83]|
|cosine4|M3|ATP|90.15 ± 0.28|91.99 ± 0.42|-1.83|[-3.98, 0.31]|
|primary30|M0|Full（未监督诊断）|44.21 ± 7.60|42.11 ± 14.59|2.11|[-4.56, 8.65]|
|primary30|M1|Full|94.97 ± 3.26|97.78 ± 2.98|-2.81|[-5.03, -0.70]|
|primary30|M2|Full|93.92 ± 1.07|99.42 ± 1.01|-5.50|[-7.95, -3.27]|
|primary30|M3|Full|96.37 ± 2.94|100.00 ± 0.00|-3.63|[-5.26, -2.22]|
|prefix30|M0|Full（未监督诊断）|44.21 ± 7.60|41.87 ± 14.99|2.34|[-4.44, 9.12]|
|prefix30|M1|Full|94.97 ± 3.26|99.18 ± 0.73|-4.21|[-6.32, -2.34]|
|prefix30|M2|Full|93.92 ± 1.07|99.30 ± 1.22|-5.38|[-7.84, -3.04]|
|prefix30|M3|Full|96.37 ± 2.94|99.65 ± 0.35|-3.27|[-4.91, -1.75]|
|cosine4|M0|Full（未监督诊断）|44.21 ± 7.60|42.81 ± 13.07|1.40|[-5.26, 8.19]|
|cosine4|M1|Full|94.97 ± 3.26|99.77 ± 0.20|-4.80|[-7.02, -2.81]|
|cosine4|M2|Full|93.92 ± 1.07|99.88 ± 0.20|-5.96|[-8.42, -3.74]|
|cosine4|M3|Full|96.37 ± 2.94|99.77 ± 0.41|-3.39|[-5.03, -1.87]|
|primary30|M0|ROI（未监督诊断）|51.11 ± 2.34|39.65 ± 17.34|11.46|[4.68, 18.25]|
|primary30|M1|ROI|94.85 ± 3.69|62.46 ± 16.27|32.40|[27.95, 36.96]|
|primary30|M2|ROI|94.27 ± 0.41|54.15 ± 2.03|40.12|[34.85, 45.38]|
|primary30|M3|ROI|97.43 ± 2.34|99.88 ± 0.20|-2.46|[-3.98, -1.17]|
|prefix30|M0|ROI（未监督诊断）|51.11 ± 2.34|39.18 ± 16.70|11.93|[5.03, 18.71]|
|prefix30|M1|ROI|94.85 ± 3.69|56.73 ± 6.52|38.13|[33.10, 43.16]|
|prefix30|M2|ROI|94.27 ± 0.41|61.05 ± 3.35|33.22|[28.42, 38.25]|
|prefix30|M3|ROI|97.43 ± 2.34|99.88 ± 0.20|-2.46|[-3.98, -1.17]|
|cosine4|M0|ROI（未监督诊断）|51.11 ± 2.34|36.73 ± 18.17|14.39|[7.95, 20.82]|
|cosine4|M1|ROI|94.85 ± 3.69|63.27 ± 17.72|31.58|[27.25, 36.02]|
|cosine4|M2|ROI|94.27 ± 0.41|65.61 ± 2.46|28.65|[24.09, 33.45]|
|cosine4|M3|ROI|97.43 ± 2.34|100.00 ± 0.00|-2.57|[-4.09, -1.29]|

全部108项逐种子比较、正确数、互有胜负数和Holm108结果见同名CSV/JSON。
