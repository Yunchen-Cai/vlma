"""Frozen CLIP projected/unit-normalized features and fixed final linear head."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',USE_TF='0',USE_FLAX='0',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8')
import json,time,random,hashlib,platform
from pathlib import Path
import numpy as np
import torch
from PIL import Image
from transformers import CLIPModel,AutoProcessor
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'E1-AB_20261027'
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def main():
 torch.set_num_threads(6);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
 rows=read(BASE/'data/source_manifest.json');assert len(rows)==497
 for rel,h in read(BASE/'config/runtime_lock.json')['protected_file_hashes'].items():assert sha(BASE/rel)==h
 rois={r['source_id']:r for r in read(BASE/'data/roi_manifest.json')}
 for r in rows:
  assert sha(BASE/r['full_path'])==r['full_sha256'];assert sha(BASE/r['roi_path'])==rois[r['source_id']]['roi_sha256']
 modeldir=ROOT/'weights';hashes=read(ROOT/'weights_hashes.json')
 for name,h in hashes.items():assert sha(modeldir/name)==h
 save(ROOT/'runtime.json',{'torch':torch.__version__,'python':platform.python_version(),'gpu':torch.cuda.get_device_name(),'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'weights':hashes,'protocol_sha256':sha(ROOT/'protocol.json'),'script_sha256':sha(Path(__file__))})
 processor=AutoProcessor.from_pretrained(modeldir,local_files_only=True)
 model=CLIPModel.from_pretrained(modeldir,local_files_only=True).cuda().eval()
 pairs=[(r,v) for r in rows for v in ['Full','ROI']];features=[]
 for i in range(0,len(pairs),16):
  batch=pairs[i:i+16];images=[]
  for r,v in batch:
   with Image.open(BASE/r['full_path' if v=='Full' else 'roi_path']) as im:images.append(im.convert('RGB'))
  inputs=processor(images=images,return_tensors='pt').to('cuda')
  with torch.inference_mode():x=model.get_image_features(**inputs).float();x=torch.nn.functional.normalize(x,dim=-1)
  assert torch.isfinite(x).all();features.append(x.cpu());print('features',i+len(batch),'/994',flush=True)
 feats=torch.cat(features);assert feats.shape==(994,512)
 torch.save(feats,ROOT/'features.pt');save(ROOT/'feature_manifest.json',[{'source_id':r['source_id'],'split':r['split'],'view':v,'gt':int(r['gt_status']=='Finish')} for r,v in pairs])
 del model;torch.cuda.empty_cache();feats=feats.cuda()
 labels=torch.tensor([int(r['gt_status']=='Finish') for r,v in pairs],device='cuda')
 lookup={(r['source_id'],v):i for i,(r,v) in enumerate(pairs)};test=[i for i,(r,v) in enumerate(pairs) if r['split']=='test'];assert len(test)==570
 completed=[]
 for seed in [42,43,44]:
  for group in ['full','roi','mixed','full_repeat2']:
   dest=ROOT/'runs'/f'{group}_s{seed}';dest.mkdir(parents=True,exist_ok=False)
   random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
   indices=[lookup[r['source_id'],v] for r in rows if r['split']=='train' for v in {'full':['Full'],'roi':['ROI'],'mixed':['Full','ROI'],'full_repeat2':['Full','Full']}[group]]
   model=torch.nn.Linear(512,2).cuda();opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=.01);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30)
   gen=torch.Generator().manual_seed(seed);step=0;t=time.monotonic()
   for epoch in range(30):
    order=torch.randperm(len(indices),generator=gen).tolist();n=0;loss_sum=0
    for start in range(0,len(order),32):
     idx=[indices[j] for j in order[start:start+32]];opt.zero_grad(set_to_none=True);loss=torch.nn.functional.cross_entropy(model(feats[idx]),labels[idx]);assert torch.isfinite(loss)
     loss.backward();opt.step();step+=1;n+=len(idx);loss_sum+=float(loss.detach())*len(idx)
    assert n==len(indices)
    with (dest/'epochs.jsonl').open('a') as f:f.write(json.dumps({'epoch':epoch+1,'n':n,'loss':loss_sum/n,'lr_used':opt.param_groups[0]['lr'],'steps':step})+'\n')
    sched.step()
   torch.cuda.synchronize();elapsed=time.monotonic()-t;torch.save(model.state_dict(),dest/'final.pt');checkpoint=sha(dest/'final.pt')
   with torch.inference_mode():probs=model(feats[test]).float().softmax(-1).cpu().tolist()
   pred=[]
   for i,prob in zip(test,probs):
    r,v=pairs[i];pred.append({'source_id':r['source_id'],'view':v,'gt':int(r['gt_status']=='Finish'),'prediction':int(prob[1]>prob[0]),'prob_unfinish':prob[0],'prob_finish':prob[1],'checkpoint_sha256':checkpoint})
   assert len({(p['source_id'],p['view']) for p in pred})==570
   (dest/'predictions.jsonl').write_text(''.join(json.dumps(p)+'\n' for p in pred));metrics={}
   for view in ['Full','ROI']:
    rs=[p for p in pred if p['view']==view];tp=sum(p['gt']==1 and p['prediction']==1 for p in rs);tn=sum(p['gt']==0 and p['prediction']==0 for p in rs);fp=sum(p['gt']==0 and p['prediction']==1 for p in rs);fn=sum(p['gt']==1 and p['prediction']==0 for p in rs)
    assert tp+fn==141 and fp+tn==144
    metrics[view]={'TP':tp,'TN':tn,'FP':fp,'FN':fn,'accuracy':(tp+tn)/285,'FPR':fp/144,'recall':tp/141}
   save(dest/'completion.json',{'completed':True,'seed':seed,'group':group,'epochs':30,'updates':step,'training_examples':len(indices)*30,'selection':'fixed final epoch30','checkpoint_sha256':checkpoint,'predictions_sha256':sha(dest/'predictions.jsonl'),'training_seconds':elapsed,'metrics':metrics})
   completed.append(dest.name);save(ROOT/'status.json',{'status':'running','completed':completed});print(dest.name,metrics,flush=True)
 save(ROOT/'status.json',{'status':'completed','completed':completed,'finished_at':time.time()})
if __name__=='__main__':main()
