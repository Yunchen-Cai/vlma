"""Frozen fixtures + actual Java scheduler, separate from original immutable core."""
import datetime, hashlib, itertools, json, shutil, subprocess, time
from pathlib import Path
R=Path(__file__).resolve().parents[1]
D=R/'E7_promise_scheduler_20261029'
CLI=R/'incoming_fsm_P0_update_20261029/java_cli'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def jsonl(p,rows):p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
assert not D.exists(), 'Do not overwrite any prior run'
D.mkdir()
protocol=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    implementation='NEW revision adapter PromiseScheduler around unchanged original Java core; not a historical implementation result',
    scopes=['synthetic author-confirmed 15-node SOP software contracts','real held-out endpoint predictions under artificial pending-verification context','CPU JSON parse + response validation + core update + hard admission + alarm episode delta + next-request selection + snapshot + serialization'],
    excluded=['VLM inference','network','file IO in per-call timer','JVM startup in per-call timer','real video alarm precision/recall/delay','real screw instance recognition','production quotas'],
    policies=dict(target='first eligible evidence-ready V node in SOP order; otherwise G; V retry can block G until resolved',
      admission='current touched node, all parents previously admitted, original core done; no automatic admission of stale out-of-order evidence',
      verification='Finish latches at original threshold; Unfinish/Unknown do not release; no rollback after admission',
      confidence='global confidence ON; synthetic unit confidence or manually assigned contract scalar; real V predictions use unit confidence because token confidence unavailable',
      latency='two warm-up workload passes, five formal passes; timer excludes final JSON reparse/envelope/file IO; all tails retained; repetitions not independent videos'),
    original_jar_sha256=sha(CLI/'fsm-cli.jar'),adapter_sha256=sha(R/'scripts/PromiseScheduler.java'),runner_sha256=sha(Path(__file__)))
dump(D/'protocol_before_results.json',protocol)
sop=read(R/'E6-D_author_barrier_contract_20261029/synthetic_author_graph.sop.json')
sop['sop_id']='REVISION_SCHEDULER_AUTHOR_GRAPH_SYNTHETIC'
sop['nodes'][6]['condition']='PortEndCover_seated'
dump(D/'author_graph.sop.json',sop)
small=read(CLI/'examples/three_node_INTERFACE_ONLY.sop.json')
small['sop_id']='REVISION_ENDPOINT_CONDITIONAL_NOT_VIDEO'
small['nodes']=small['nodes'][:1]
small['nodes'][0]['condition']='PortEndCover_seated'
small['nodes'][0]['actions']=['SYNTHETIC_PENDING_ENDPOINT']
small['nodes'][0]['upper_seconds']=1000
dump(D/'endpoint.sop.json',small)
rows=[]; expectations=[]; clock=0
def reset(case):
    global clock
    clock=0;rows.append(dict(case_id=case,op='reset'))
    expectations.append(dict(index=len(rows)-1,admitted=[],mode='General'))
def response(case,mode='General',**kw):
    global clock
    clock+=1000
    row=dict(mode=mode,timestamp_ms=clock,confidence=1.0,**kw)
    rows.append(dict(case_id=case,bind_current_request=True,response=row))
    return len(rows)-1
def g(case,node):return response(case,action_key=f'SYNTHETIC_UNIQUE_NODE_{node}')
def v(case,label='finish',**kw):
    return response(case,mode='Verification',node_id=7,target_condition='PortEndCover_seated',verification_label=label,**kw)
perms=list(itertools.permutations(range(8,12)))
for a in perms:
    for b in itertools.permutations(range(12,16)):
        case='legal_'+''.join(map(str,a))+'_'+''.join(map(str,b));reset(case)
        g(case,1)
        for n in range(1,8):g(case,n)
        expectations.append(dict(index=len(rows)-1,mode='Verification',admitted=list(range(1,7))))
        v(case)
        for n in a+b:g(case,n)
        expectations.append(dict(index=len(rows)-1,mode='Complete',admitted=list(range(1,16))))
# All proper insertion subsets, each of four premature tightening nodes.
for mask in range(15):
    subset=[8+i for i in range(4) if mask&(1<<i)]
    for early in range(12,16):
        case=f'barrier_{mask}_{early}';reset(case);g(case,1)
        for n in range(1,8):g(case,n)
        v(case)
        for n in subset:g(case,n)
        idx=g(case,early)
        expectations.append(dict(index=idx,admitted=list(range(1,8))+subset,alarm_onset_contains=f'adapter_dependency_violation:{early}'))
# Verification binding and warning lifecycle, manually specified independent expectations.
case='binding_and_alarm';reset(case);g(case,1)
for n in range(1,8):g(case,n)
expectations.append(dict(index=len(rows)-1,mode='Verification'))
idx=v(case,'unknown');expectations.append(dict(index=idx,admitted=list(range(1,7)),mode='Verification'))
idx=v(case,'unfinish');expectations.append(dict(index=idx,alarm_onset_contains='unfinished:7'))
idx=v(case,'unknown');expectations.append(dict(index=idx,alarm_onset_excludes='unfinished:7'))
idx=response(case,mode='Verification',node_id=8,target_condition='wrong',verification_label='finish')
expectations.append(dict(index=idx,reject='wrong_target',admitted=list(range(1,7))))
idx=response(case,action_key='SYNTHETIC_UNIQUE_NODE_8');expectations.append(dict(index=idx,reject='wrong_mode'))
idx=v(case);expectations.append(dict(index=idx,admitted=list(range(1,8)),mode='General',alarm_resolved_contains='unfinished:7'))
old_id='637:999999'
rows.append(dict(case_id=case,response=dict(request_id=old_id,mode='General',timestamp_ms=999999,confidence=1,action_key='SYNTHETIC_UNIQUE_NODE_8')))
expectations.append(dict(index=len(rows)-1,reject='stale_or_unknown_request'))
# Low confidence Finish cannot confirm, then exact threshold does.
case='confidence_boundary';reset(case);g(case,1)
for n in range(1,8):g(case,n)
idx=v(case);rows[idx]['response']['confidence']=0.599999
expectations.append(dict(index=idx,mode='Verification',admitted=list(range(1,7))))
idx=v(case);rows[idx]['response']['confidence']=0.6
expectations.append(dict(index=idx,mode='General',admitted=list(range(1,8))))
# Duplicate delivery has no state effect; derive request ID from known epoch/serial, not output.
case='duplicates_and_reset';reset(case)
epoch=sum(x.get('op')=='reset' for x in rows)+1
idx=g(case,1);dup=dict(rows[idx]['response'],request_id=f'{epoch}:1')
rows.append(dict(case_id=case,response=dup));expectations.append(dict(index=len(rows)-1,reject='duplicate_response',admitted=[]))
idx=g(case,1);expectations.append(dict(index=idx,admitted=[1]))
idx=g(case,1);expectations.append(dict(index=idx,admitted=[1]))
reset('reset_isolation')
rows.append(dict(case_id='reset_isolation',response=dup));expectations.append(dict(index=len(rows)-1,reject='stale_or_unknown_request',admitted=[]))
jsonl(D/'contracts.input.jsonl',rows);dump(D/'independent_expectations.json',expectations)
shutil.copy2(R/'scripts/PromiseScheduler.java',D/'PromiseScheduler.java')
docker=['docker','run','--rm','--network','none','--user','1001:1001','--cpus','4',
 '--mount',f'type=bind,src={CLI},dst=/cli,readonly','--mount',f'type=bind,src={D},dst=/work','jms-fsm-core-check:20261028']
cp='/cli/fsm-cli.jar:/cli/lib/*:/work/classes'
def call(args,log):
    t=time.monotonic();p=subprocess.run(docker+args,capture_output=True,text=True,timeout=300)
    (D/log).write_text(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(p.stderr)
    return time.monotonic()-t
call(['javac','-cp',cp,'-d','/work/classes','/work/PromiseScheduler.java'],'compile.log')
def run(sop,input,output):return call(['java','-Xms256m','-Xmx2048m','-XX:ActiveProcessorCount=4','-cp',cp,'fsmcli.PromiseScheduler','/work/'+sop,'/work/'+input,'/work/'+output],output+'.log')
wall=run('author_graph.sop.json','contracts.input.jsonl','contracts.trace.jsonl')
trace=[json.loads(x)['result'] for x in (D/'contracts.trace.jsonl').read_text().splitlines()]
failures=[]
for ex in expectations:
    got=trace[ex['index']];state=got['state']
    for key,value in ex.items():
        ok=True
        if key=='mode':ok=state['request']['mode']==value
        elif key=='admitted':ok=set(state['admitted'])==set(value)
        elif key=='reject':ok=got.get('accepted') is False and got.get('reason')==value
        elif key.endswith('_contains'):ok=value in got.get(key[:-9],[])
        elif key.endswith('_excludes'):ok=value not in got.get(key[:-9],[])
        if not ok:failures.append(dict(expected=ex,got=got,failed_key=key))
dump(D/'contract_audit.json',dict(passed=not failures,expectations=len(expectations),observations=len(rows),legal_permutations=576,proper_subset_barriers=60,wall_seconds=wall,failures=failures))
print(json.dumps(dict(stage='contracts',passed=not failures,failures=len(failures)),ensure_ascii=False),flush=True)
if failures:raise RuntimeError('Contract failures retained; do not claim pass')
# Conditional real endpoint inputs: GT stays exclusively in separate scoring file.
projects={**read(R/'matched1gpu_projects_20261029.json'),**read(R/'recovery_followup_projects_20261029.json')}
real=[];truth=[];sources={}
for model,project in sorted(projects.items()):
    group=model.split('_')[0];p=R/'cloud_mirror'/project/'results'/group/'predictions.jsonl'
    sources[str(p)]=sha(p)
    rr=[json.loads(x) for x in p.read_text().splitlines()]
    endpoint=[x for x in rr if x['task']!='ATP']
    assert len(endpoint)==570
    for x in endpoint:
        case=model+'_'+x['source_id']+'_'+x['view']
        real.append(dict(case_id=case,op='reset'))
        for t in (0,1000):real.append(dict(case_id=case,bind_current_request=True,response=dict(mode='General',action_key='SYNTHETIC_PENDING_ENDPOINT',timestamp_ms=t,confidence=1)))
        try:
            parsed=json.loads(x['raw_output']);label=parsed.get('verification','unknown').lower()
            if parsed.get('part')!='Port End Cover' or set(parsed)!={'part','verification'}:label='unknown'
        except (ValueError,AttributeError):label='unknown'
        if label not in ('finish','unfinish'):label='unknown'
        real.append(dict(case_id=case,bind_current_request=True,response=dict(mode='Verification',node_id=1,target_condition='PortEndCover_seated',verification_label=label,timestamp_ms=2000,confidence=1)))
        truth.append(dict(index=len(real)-1,case_id=case,model=model,view=x['view'],source_id=x['source_id'],gt=x['gt'],parsed_label=label))
jsonl(D/'real_endpoint.input.jsonl',real);jsonl(D/'real_endpoint.truth_ONLY_SCORER.jsonl',truth);dump(D/'prediction_sources.json',sources)
run('endpoint.sop.json','real_endpoint.input.jsonl','real_endpoint.trace.jsonl')
tr=[json.loads(x)['result'] for x in (D/'real_endpoint.trace.jsonl').read_text().splitlines()]
scores={}
for x in truth:
    got=tr[x['index']];assert got['accepted']
    released=1 in got['state']['admitted'];assert released==(x['parsed_label']=='finish')
    key=x['model']+'_'+x['view'];s=scores.setdefault(key,dict(n=0,released=0,blocked=0,unknown=0,false_release=0,false_block=0,gt_finish=0,gt_unfinish=0))
    s['n']+=1;s['released']+=released;s['blocked']+=not released;s['unknown']+=x['parsed_label']=='unknown'
    actual=x['gt']['verification'].lower();assert actual in ('finish','unfinish')
    s['gt_finish']+=actual=='finish';s['gt_unfinish']+=actual=='unfinish'
    s['false_release']+=released and actual=='unfinish';s['false_block']+=not released and actual=='finish'
dump(D/'real_endpoint_integration.json',dict(passed=True,cases=len(truth),groups=scores,scope='Static held-out predictions + artificial ready-to-verify context; release errors inherit perception errors, not independent alarm gains. Ground truth is not passed to Java.'))
# Full CPU chain timing on the 15-node synthetic workload: separate repeats, warm-up excluded.
timing_rows=[]
for rep in range(-2,5):
    out=f'timing_{rep}.trace.jsonl';elapsed=run('author_graph.sop.json','contracts.input.jsonl',out)
    rr=[json.loads(x) for x in (D/out).read_text().splitlines()]
    for inp,x in zip(rows,rr):timing_rows.append(dict(repeat=rep,reset=inp.get('op')=='reset',accepted=x['result'].get('accepted'),ns=x['cpu_chain_ns']))
    print(json.dumps(dict(stage='timing',repeat=rep,wall_seconds=elapsed)),flush=True)
jsonl(D/'cpu_timings.jsonl',timing_rows)
def stats(vals):
    vals=sorted(v/1000 for v in vals);n=len(vals)
    def q(p):
        a=(n-1)*p;i=int(a);return vals[i]+(vals[min(i+1,n-1)]-vals[i])*(a-i)
    return dict(n=n,mean_us=sum(vals)/n,p50_us=q(.5),p95_us=q(.95),p99_us=q(.99),max_us=vals[-1])
timing=dict(formal=stats([x['ns'] for x in timing_rows if x['repeat']>=0 and not x['reset'] and x['accepted']]),
 reset=stats([x['ns'] for x in timing_rows if x['repeat']>=0 and x['reset']]),
 scope=protocol['scopes'][2],excluded=protocol['excluded'],cpu=json.loads(subprocess.check_output(['lscpu','-J'],text=True)),container_cpu_quota=4)
dump(D/'cpu_timing_results.json',timing)
assert sha(CLI/'fsm-cli.jar')==protocol['original_jar_sha256']
assert all(sha(Path(p))==h for p,h in sources.items())
dump(D/'completed.json',dict(complete=True,contracts_passed=True,real_endpoint_cases=len(truth),original_core_unchanged=True,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timing=timing['formal']))
print(json.dumps(read(D/'completed.json')),flush=True)
