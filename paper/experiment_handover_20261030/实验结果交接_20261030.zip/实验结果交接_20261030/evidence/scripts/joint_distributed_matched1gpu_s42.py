"""Single-GPU recovery follow-up; unchanged global examples/updates and resumable state."""
import os,json,time,math,random,hashlib,shutil,gc,argparse,contextlib,datetime
from pathlib import Path
import joint_worker as task
from joint_worker import torch,engine,seed_all,load_processor,write_json,sha256,read_json
import numpy as np
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from transformers import get_linear_schedule_with_warmup
R=Path(__file__).resolve().parents[1]
def atomic_json(p,v):
 temp=p.with_suffix('.tmp');temp.write_text(json.dumps(v,indent=2)+'\n');temp.replace(p)
def cpu(x):
 if torch.is_tensor(x):return x.detach().cpu()
 if isinstance(x,dict):return {k:cpu(v) for k,v in x.items()}
 if isinstance(x,list):return [cpu(v) for v in x]
 if isinstance(x,tuple):return tuple(cpu(v) for v in x)
 return x
def train(group,max_updates):
 rank=int(os.environ['RANK']);world=int(os.environ['WORLD_SIZE']);local=int(os.environ['LOCAL_RANK']);assert world==1;torch.cuda.set_device(local);torch.set_num_threads(6)
 dist.init_process_group('nccl',timeout=datetime.timedelta(minutes=30));run=R/'runs'/group;run.mkdir(parents=True,exist_ok=True);checkpoint_dir=run/'checkpoints';checkpoint_dir.mkdir(exist_ok=True)
 rows=task.check_inputs();mapping={r['source_id']:r for r in rows};samples=[]
 for r in rows:
  if r['split']!='train':continue
  views=['Full'] if r['task']=='ATP' else {'M0':[],'M1':['Full'],'M2':['Full','Full'],'M3':['Full','ROI']}[group]
  for i,v in enumerate(views):samples.append({'source_id':r['source_id'],'view':v,'example_id':r['source_id']+'::'+v+'::'+str(i)})
 assert len(samples)=={'M0':1709,'M1':1921,'M2':2133,'M3':2133}[group]
 cfg=read_json(R/'recovery_config.json');seed=cfg['seed'];assert seed == 42
 seed_all(seed);processor=load_processor()
 for task_name in ('ATP','verification'):
  row=next(r for r in rows if r['split']=='train' and r['task']==task_name);task.encode(processor,row,'Full',True,verify_mask=True)
 model=engine.load_model();model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.train()
 opt,inner,groups=engine.make_optimizer(model,'native');per_epoch=math.ceil(len(samples)/32);total=4*per_epoch;scheduler=get_linear_schedule_with_warmup(inner,num_warmup_steps=math.ceil(.03*total),num_training_steps=total)
 records=[];step=0;epoch_records=[];latest=checkpoint_dir/'latest.json';resumed=False
 if latest.exists():
  pointer=read_json(latest);p=checkpoint_dir/pointer['file'];assert sha256(p)==pointer['sha256'];state=torch.load(p,map_location='cpu',weights_only=False);assert state['group']==group and state['world_size']==world and state['samples']==samples
  assert state['seed']==seed and state['code_hashes']==read_json(R/'evidence/frozen_code_hashes.json')
  model.load_state_dict(state['model'],strict=True);inner.load_state_dict(state['optimizer']);scheduler.load_state_dict(state['scheduler']);step=state['step'];records=state['records'];epoch_records=state['epoch_records'];assert len(records)==step
  rng=state['rng'][rank];random.setstate(rng['python']);np.random.set_state(rng['numpy']);torch.set_rng_state(rng['torch']);torch.cuda.set_rng_state(rng['cuda'],local);resumed=True
  if rank==0:
   # Full tensor comparison establishes that the loaded model equals the committed snapshot.
   assert all(torch.equal(v.detach().cpu(),state['model'][k]) for k,v in model.state_dict().items())
   write_json(run/f'resume_audit_step{step:06d}.json',{'passed':True,'checkpoint_sha256':pointer['sha256'],'step':step,'model_all_tensors_equal':True,'optimizer_and_scheduler_loaded':True,'rank_rng_restored':True,'time':time.time()})
  del state;gc.collect();torch.cuda.empty_cache()
 if rank==0:
  write_json(run/'parameter_groups.json',groups);write_json(run/'training_manifest.json',samples)
  write_json(run/'run_config.json',{'group':group,'seed':seed,'epochs':4,'samples_per_epoch':len(samples),'updates':total,'world_size':world,'effective_global_batch':32,'selection':'fixed final epoch4','atp_prompt':task.PROMPT,'cover_prompt':task.COVER_PROMPT,'loss':'global mean of per-example assistant+EOS mean; scale local loss by world_size/global_chunk_size before DDP gradient average','recovery_run':True})
  # Logs beyond a committed state are retained separately, never silently counted twice.
  for name,retained in [('updates.jsonl',records),('epoch_coverage.jsonl',epoch_records)]:
   p=run/name
   if p.exists():shutil.copy2(p,run/(name+'.before_resume_'+str(int(time.time()))))
   p.write_text(''.join(json.dumps(x)+'\n' for x in retained))
 dist.barrier();model=DDP(model,device_ids=[local],output_device=local,broadcast_buffers=False,gradient_as_bucket_view=True)
 def snapshot():
  rng={'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state(local)};rngs=[None]*world;dist.all_gather_object(rngs,rng)
  if rank==0:
   start=time.monotonic();p=checkpoint_dir/f'state_{step:06d}.pt';tmp=p.with_suffix('.partial');payload={'model':cpu(model.module.state_dict()),'optimizer':cpu(inner.state_dict()),'scheduler':scheduler.state_dict(),'step':step,'records':records,'epoch_records':epoch_records,'group':group,'seed':seed,'world_size':world,'samples':samples,'rng':rngs,'code_hashes':read_json(R/'evidence/frozen_code_hashes.json')}
   torch.save(payload,tmp)
   with tmp.open('rb') as f:os.fsync(f.fileno())
   digest=sha256(tmp);tmp.replace(p);atomic_json(latest,{'file':p.name,'sha256':digest,'step':step,'bytes':p.stat().st_size,'saved_at':time.time()});del payload;gc.collect()
   engine.event(run/'checkpoint_events.jsonl',{'step':step,'seconds':time.monotonic()-start,'sha256':digest,'bytes':p.stat().st_size})
   committed=sorted(checkpoint_dir.glob('state_*.pt'))
   for old in committed[:-2]:old.unlink()
  dist.barrier()
 for epoch in range(4):
  ordered=list(samples);random.Random(seed+epoch).shuffle(ordered)
  for start in range(0,len(ordered),32):
   idx=epoch*per_epoch+start//32+1
   if idx<=step:continue
   examples=ordered[start:start+32];local_examples=examples[rank::world];padding=not local_examples;forward_examples=local_examples or [examples[0]]
   torch.cuda.reset_peak_memory_stats();tick=time.monotonic();opt.zero_grad(set_to_none=True);loss_sum=0.;visual=0;tokens=0
   for j,e in enumerate(forward_examples):
    inputs,meta=task.encode(processor,mapping[e['source_id']],e['view'],True);inputs=engine.to_device(inputs)
    sync=contextlib.nullcontext() if j==len(forward_examples)-1 else model.no_sync()
    with sync:
     out=model(**inputs,use_cache=False);loss=out.loss
     if not torch.isfinite(loss).item():raise RuntimeError('nonfinite loss '+e['example_id'])
     if not padding:loss_sum+=float(loss.detach());visual+=meta['visual_tokens'];tokens+=meta['input_tokens']
     (loss*(0. if padding else world/len(examples))).backward()
    del inputs,out,loss
   if idx==1:
    missing=[n for n,p in model.module.named_parameters() if p.grad is None];assert not missing,missing
   norm=torch.nn.utils.clip_grad_norm_(model.module.parameters(),1.,error_if_nonfinite=True,foreach=False);lr=inner.param_groups[0]['lr'];opt.step();scheduler.step();opt.zero_grad(set_to_none=True);torch.cuda.synchronize();elapsed=time.monotonic()-tick
   stats=[None]*world;dist.all_gather_object(stats,{'loss_sum':loss_sum,'visual':visual,'tokens':tokens,'seconds':elapsed,'ids':[e['example_id'] for e in local_examples],'zero_weight_padding_forwards':int(padding),'padding_input_tokens':meta['input_tokens'] if padding else 0,'padding_visual_tokens':meta['visual_tokens'] if padding else 0});step=idx
   assert sorted(x for s in stats for x in s['ids'])==sorted(e['example_id'] for e in examples)
   record={'time':time.time(),'update':step,'samples':len(examples),'example_ids':[e['example_id'] for e in examples],'mean_sample_loss':sum(s['loss_sum'] for s in stats)/len(examples),'gradient_norm_before_clipping':float(norm),'learning_rate_used':lr,'visual_tokens':sum(s['visual'] for s in stats),'input_tokens':sum(s['tokens'] for s in stats),'elapsed_seconds':max(s['seconds'] for s in stats),'world_size':world}
   record.update(peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved(),zero_weight_padding_forwards=sum(s['zero_weight_padding_forwards'] for s in stats),padding_input_tokens=sum(s['padding_input_tokens'] for s in stats),padding_visual_tokens=sum(s['padding_visual_tokens'] for s in stats))
   records.append(record)
   end_epoch=start+32>=len(ordered)
   if end_epoch:
    seen=[eid for rec in records[epoch*per_epoch:(epoch+1)*per_epoch] for eid in rec['example_ids']]
    assert sorted(seen)==sorted(e['example_id'] for e in samples)
    epoch_records.append({'time':time.time(),'epoch':epoch+1,'coverage_exact':True,'samples':len(seen)})
   if rank==0:
    engine.event(run/'updates.jsonl',record);write_json(run/'progress.json',{'epoch':epoch+1,'updates':step,'examples_in_epoch':min(start+32,len(samples)),'world_size':world,'resumed':resumed,'time':time.time()})
    if end_epoch:engine.event(run/'epoch_coverage.jsonl',epoch_records[-1])
   if step==1 or step%16==0 or end_epoch or (max_updates and step>=max_updates):snapshot()
   if max_updates and step>=max_updates:dist.barrier();dist.destroy_process_group();return
 assert step==total and len(epoch_records)==4
 dist.barrier()
 if rank==0:
  model.module.eval();model.module.gradient_checkpointing_disable();hashes=engine.save_model(model.module,processor,run/'final');write_json(run/'completion.json',{'completed':True,'group':group,'seed':seed,'epochs':4,'updates':step,'world_size':world,'examples':sum(x['samples'] for x in records),'visual_tokens':sum(x['visual_tokens'] for x in records),'training_update_seconds':sum(x['elapsed_seconds'] for x in records),'file_hashes':hashes,'finished_at':time.time(),'recovery_run':True})
 dist.barrier();dist.destroy_process_group()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('group',choices=['M0','M1','M2','M3']);p.add_argument('--max-updates',type=int,default=0);a=p.parse_args();train(a.group,a.max_updates)
