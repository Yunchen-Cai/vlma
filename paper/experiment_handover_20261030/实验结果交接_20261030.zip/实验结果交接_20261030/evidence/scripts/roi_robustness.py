from confidence_diagnostic import ROOT,BASE,MODEL,sha,save
import json,time,subprocess,traceback
from pathlib import Path
import torch
from PIL import Image
from transformers import AutoProcessor,Qwen2_5_VLForConditionalGeneration
OUT=ROOT/'roi_robustness';CONDS=['original','left10','right10','up10','down10','scale80','scale120']
def box_for(box,w,h,condition):
 x1,y1,x2,y2=box;bw=x2-x1;bh=y2-y1;cx=(x1+x2)/2;cy=(y1+y2)/2
 dx={'left10':-.1,'right10':.1}.get(condition,0)*bw;dy={'up10':-.1,'down10':.1}.get(condition,0)*bh;s={'scale80':.8,'scale120':1.2}.get(condition,1)
 b=[int(max(0,cx+dx-bw*s/2)),int(max(0,cy+dy-bh*s/2)),int(min(w,cx+dx+bw*s/2)),int(min(h,cy+dy+bh*s/2))]
 assert 0<=b[0]<b[2]<=w and 0<=b[1]<b[3]<=h
 if condition=='original':assert b==box
 return b
def main():
 OUT.mkdir(exist_ok=True);dest=OUT/'predictions.jsonl'
 if dest.exists():raise RuntimeError('Refuse existing perturbation predictions')
 assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip(),'Compute GPU occupied'
 for name,h in json.loads((MODEL/'file_hashes.json').read_text()).items():assert sha(MODEL/name)==h
 rows=[r for r in json.loads((BASE/'data/source_manifest.json').read_text()) if r['split']=='test'];assert len(rows)==285
 for r in rows:assert sha(BASE/r['full_path'])==r['full_sha256']
 save(OUT/'frozen_run.json',{'started_at':time.time(),'protocol_sha256':sha(ROOT/'E2-B_ROI扰动协议.md'),'script_sha256':sha(Path(__file__)),'model_hashes':json.loads((MODEL/'file_hashes.json').read_text()),'conditions':CONDS,'sources':285,'torch':torch.__version__})
 torch.set_num_threads(8);processor=AutoProcessor.from_pretrained(MODEL,local_files_only=True);model=Qwen2_5_VLForConditionalGeneration.from_pretrained(MODEL,torch_dtype=torch.bfloat16,attn_implementation='sdpa',local_files_only=True).cuda().eval()
 prompt=(BASE/'config/prompt.txt').read_text();msg=[{'role':'user','content':[{'type':'image','image':'frame.jpg'},{'type':'text','text':prompt}]}];text=processor.apply_chat_template(msg,tokenize=False,add_generation_prompt=True);allrows=[]
 for r in rows:
  with Image.open(BASE/r['full_path']) as f:full=f.convert('RGB')
  for cond in CONDS:
   b=box_for(r['expanded_box'],*full.size,cond);im=full.crop(b);ins=processor(text=[text],images=[im],padding=False,return_tensors='pt').to('cuda');n=ins['input_ids'].shape[1]
   with torch.inference_mode():out=model.generate(**ins,max_new_tokens=128,do_sample=False,num_beams=1,use_cache=True,temperature=None,top_p=None,top_k=None)
   ids=out[0,n:].tolist();raw=processor.tokenizer.decode(ids,skip_special_tokens=True,clean_up_tokenization_spaces=False);p={};valid=False
   try:p=json.loads(raw);valid=isinstance(p,dict) and set(p)=={'part','verification'} and isinstance(p['part'],str) and bool(p['part'].strip()) and p['verification'] in ('Finish','Unfinish')
   except (ValueError,TypeError):pass
   item={'source_id':r['source_id'],'condition':cond,'gt_status':r['gt_status'],'box':b,'image_size':list(im.size),'raw_output':raw,'strict_valid':valid,'pred_status':p.get('verification') if valid else None,'status_correct':valid and p['verification']==r['gt_status'],'joint_correct':valid and p['verification']==r['gt_status'] and p['part']=='Port End Cover','output_token_ids':ids}
   allrows.append(item)
   with dest.open('a') as f:f.write(json.dumps(item)+'\n')
  if len(allrows)%70==0:print('completed',len(allrows),'/1995',flush=True)
 assert len(allrows)==1995 and len({(r['source_id'],r['condition']) for r in allrows})==1995
 orig={r['source_id']:r for r in allrows if r['condition']=='original'};stats={}
 for cond in CONDS:
  rs=[r for r in allrows if r['condition']==cond];tp=sum(r['gt_status']=='Finish' and r['pred_status']=='Finish' for r in rs);tn=sum(r['gt_status']=='Unfinish' and r['pred_status']=='Unfinish' for r in rs);fp=sum(r['gt_status']=='Unfinish' and r['pred_status']=='Finish' for r in rs);fn=sum(r['gt_status']=='Finish' and r['pred_status']=='Unfinish' for r in rs)
  stats[cond]={'TP':tp,'TN':tn,'FP':fp,'FN':fn,'invalid':sum(not r['strict_valid'] for r in rs),'accuracy':(tp+tn)/285,'FPR':fp/144,'recall':tp/141,'correct_to_wrong':sum(orig[r['source_id']]['status_correct'] and not r['status_correct'] for r in rs),'wrong_to_correct':sum(not orig[r['source_id']]['status_correct'] and r['status_correct'] for r in rs)}
 save(OUT/'completion.json',{'completed':True,'records':1995,'unique_sources':285,'results':stats,'predictions_sha256':sha(dest),'finished_at':time.time()});print(stats,flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as e:
  OUT.mkdir(exist_ok=True);save(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
