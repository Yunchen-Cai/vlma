"""Fixed final multihead shared ResNet50; never use ground-truth phase as input."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import json,hashlib,random,time,sys,platform
from pathlib import Path
import numpy as np
import torch,torchvision
from torchvision import transforms as T
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent/'E1-AB_20261027';ASSETS=ROOT.parent/'asset_audit_20261027'
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def main(seed):
 torch.set_num_threads(6);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
 for p,h in read(ROOT/'evidence/input_gate.json')['protected_files'].items():assert sha(Path(p))==h,p
 for p,h in read(ROOT/'evidence/frozen_code_hashes.json').items():assert sha(ROOT/p)==h,p
 rows=[]
 for r in read(ASSETS/'evidence/audited_rows.json'):
  if r['task']=='ATP':rows.append({'source_id':r['id'],'split':r['split'],'task':'ATP','view':'Full','image':str(ASSETS/'objects'/r['local_object']),'hash':r['sha256'],'gt':{k:r['gt'][k] for k in ['action','tool','part']}})
 rois={r['source_id']:r for r in read(BASE/'data/roi_manifest.json')}
 for r in read(BASE/'data/source_manifest.json'):
  for v in ['Full','ROI']:rows.append({'source_id':r['source_id'],'split':r['split'],'task':'verification','view':v,'image':str(BASE/r['full_path' if v=='Full' else 'roi_path']),'hash':r['full_sha256'] if v=='Full' else rois[r['source_id']]['roi_sha256'],'gt':{'part':r['gt_part'],'verification':r['gt_status']}})
 assert len(rows)==3248 and sum(r['split']=='test' for r in rows)==1115
 vocab={k:sorted({r['gt'][k] for r in rows if r['split']=='train' and k in r['gt']}) for k in ['action','tool','part','verification']}
 assert {k:len(v) for k,v in vocab.items()}=={'action':4,'tool':3,'part':7,'verification':2}
 for r in rows:
  assert sha(Path(r['image']))==r['hash']
  for k,v in r['gt'].items():assert v in vocab[k],(r['source_id'],k,v)
 save(ROOT/'vocabulary.json',vocab);save(ROOT/'source_manifest.json',rows)
 transform=T.Compose([T.Resize((224,224),interpolation=T.InterpolationMode.BILINEAR,antialias=True),T.ToTensor(),T.Normalize([.485,.456,.406],[.229,.224,.225])])
 cached=[]
 for r in rows:
  with Image.open(r['image']) as im:cached.append(transform(im.convert('RGB')))
 x=torch.stack(cached);del cached
 targets={k:torch.tensor([vocab[k].index(r['gt'][k]) if k in r['gt'] else -100 for r in rows]) for k in vocab}
 test=[i for i,r in enumerate(rows) if r['split']=='test'];assert len(test)==1115
 weight=ROOT.parent/'E2-C_ResNet50_20261028/weights/resnet50-11ad3fa6.pth';assert sha(weight).startswith('11ad3fa6')
 class Shared(torch.nn.Module):
  def __init__(self):
   super().__init__();self.backbone=torchvision.models.resnet50(weights=None);self.backbone.load_state_dict(torch.load(weight,map_location='cpu',weights_only=True));dim=self.backbone.fc.in_features;self.backbone.fc=torch.nn.Identity();self.heads=torch.nn.ModuleDict({k:torch.nn.Linear(dim,len(v)) for k,v in vocab.items()})
  def forward(self,z):
   z=self.backbone(z);return {k:h(z) for k,h in self.heads.items()}
 save(ROOT/'runtime.json',{'python':platform.python_version(),'torch':torch.__version__,'torchvision':torchvision.__version__,'gpu':torch.cuda.get_device_name(),'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'weights_sha256':sha(weight),'transform':repr(transform),'seed':seed})
 completed=[]
 for group in ['M0','M1','M2','M3']:
  random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
  run=ROOT/'runs'/group;run.mkdir(parents=True,exist_ok=False);indices=[]
  for i,r in enumerate(rows):
   if r['split']!='train':continue
   if r['task']=='ATP':indices.append(i)
   elif group=='M1' and r['view']=='Full':indices.append(i)
   elif group=='M2' and r['view']=='Full':indices.extend([i,i])
   elif group=='M3':indices.append(i)
  assert len(indices)=={'M0':1709,'M1':1921,'M2':2133,'M3':2133}[group]
  save(ROOT/'status.json',{'status':'training','active':group,'seed':seed,'completed':completed});save(run/'training_indices.json',indices)
  model=Shared().cuda();opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=.01);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30);gen=torch.Generator().manual_seed(seed);step=0;start=time.monotonic()
  for epoch in range(30):
   model.train();order=torch.randperm(len(indices),generator=gen).tolist();n=0;total_loss=0
   for j in range(0,len(order),32):
    idx=[indices[k] for k in order[j:j+32]];inputs=x[idx].cuda();ys={k:v[idx].cuda() for k,v in targets.items()};opt.zero_grad(set_to_none=True);outputs=model(inputs)
    sums=torch.zeros(len(idx),device='cuda');counts=torch.zeros(len(idx),device='cuda')
    for k,logits in outputs.items():sums+=torch.nn.functional.cross_entropy(logits,ys[k],ignore_index=-100,reduction='none');counts+=(ys[k]!=-100).float()
    assert torch.all((counts==2)|(counts==3));loss=(sums/counts).mean();assert torch.isfinite(loss);loss.backward();opt.step();step+=1;n+=len(idx);total_loss+=float(loss.detach())*len(idx)
   assert n==len(indices)
   with (run/'epochs.jsonl').open('a') as f:f.write(json.dumps({'epoch':epoch+1,'n':n,'loss':total_loss/n,'lr_used':opt.param_groups[0]['lr'],'steps':step})+'\n')
   scheduler.step();print(group,'epoch',epoch+1,'loss',total_loss/n,flush=True)
  torch.cuda.synchronize();elapsed=time.monotonic()-start;torch.save(model.state_dict(),run/'final.pt');checkpoint=sha(run/'final.pt');model.eval();pred=[]
  for j in range(0,len(test),32):
   idx=test[j:j+32]
   with torch.inference_mode():out={k:v.argmax(-1).cpu().tolist() for k,v in model(x[idx].cuda()).items()}
   for t,i in enumerate(idx):
    r=rows[i];p={k:vocab[k][out[k][t]] for k in r['gt']};fields={k:p[k]==v for k,v in r['gt'].items()};pred.append({'source_id':r['source_id'],'task':r['task'],'view':r['view'],'gt':r['gt'],'prediction':p,'field_correct':fields,'joint_correct':all(fields.values()),'checkpoint_sha256':checkpoint})
  assert len(pred)==1115 and len({(r['source_id'],r['view']) for r in pred})==1115
  (run/'predictions.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in pred));atp=[r for r in pred if r['task']=='ATP'];assert len(atp)==545
  metrics={'ATP':{k:sum(r['field_correct'][k] for r in atp)/545 for k in ['action','tool','part']}};metrics['ATP']['joint']=sum(r['joint_correct'] for r in atp)/545
  metrics['ATP']['action_confusion']={gt:{p:sum(r['gt']['action']==gt and r['prediction']['action']==p for r in atp) for p in vocab['action']} for gt in vocab['action']}
  for view in ['Full','ROI']:
   rs=[r for r in pred if r['task']=='verification' and r['view']==view];assert len(rs)==285
   tp=sum(r['gt']['verification']=='Finish' and r['prediction']['verification']=='Finish' for r in rs);tn=sum(r['gt']['verification']=='Unfinish' and r['prediction']['verification']=='Unfinish' for r in rs);fp=sum(r['gt']['verification']=='Unfinish' and r['prediction']['verification']=='Finish' for r in rs);fn=sum(r['gt']['verification']=='Finish' and r['prediction']['verification']=='Unfinish' for r in rs);assert tp+fn==141 and tn+fp==144
   metrics[view]={'TP':tp,'TN':tn,'FP':fp,'FN':fn,'accuracy':(tp+tn)/285,'FPR':fp/144,'recall':tp/141,'part_accuracy':sum(r['field_correct']['part'] for r in rs)/285,'joint_accuracy':sum(r['joint_correct'] for r in rs)/285}
  save(run/'completion.json',{'completed':True,'group':group,'seed':seed,'epochs':30,'updates':step,'training_examples':30*len(indices),'training_seconds':elapsed,'checkpoint_sha256':checkpoint,'predictions_sha256':sha(run/'predictions.jsonl'),'metrics':metrics,'selection':'fixed final epoch30'});completed.append(group);del model,opt,scheduler;torch.cuda.empty_cache()
 save(ROOT/'status.json',{'status':'completed','seed':seed,'completed':completed,'finished_at':time.time()})
if __name__=='__main__':main(int(sys.argv[1]))
