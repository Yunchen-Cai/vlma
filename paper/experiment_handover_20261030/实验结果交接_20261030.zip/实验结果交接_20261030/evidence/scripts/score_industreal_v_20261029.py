"""Independent completeness/hash audit and paired state/memory metrics."""
from pathlib import Path
import ast,json,hashlib,collections,datetime,sys,re
R=Path(__file__).resolve().parents[1];O=R/'E6-G_industreal_visual_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def valid(x):return type(x) is int and x in (0,1)
def parsed_value(row,normalized=False):
    if not normalized:return row['parsed']
    raw=row['raw_output'].strip()
    match=re.fullmatch(r'```(?:json)?\s*([\s\S]*?)\s*```',raw)
    if match:raw=match.group(1)
    try:return json.loads(raw)
    except ValueError:return None
def metrics(rows):
    n=len(rows);known=[r for r in rows if valid(r['p'])];correct=sum(r['p']==r['y'] for r in known)
    cls={str(y):{'n':sum(r['y']==y for r in rows),'correct':sum(r['y']==y and r['p']==y for r in known)} for y in (0,1)}
    return {'n':n,'correct':correct,'accuracy_unknown_as_wrong':correct/n if n else None,'coverage':len(known)/n if n else None,'selective_accuracy':correct/len(known) if known else None,'by_true_class':cls,'balanced_accuracy':sum(c['correct']/c['n'] for c in cls.values())/2 if all(c['n'] for c in cls.values()) else None,'false_accept_installed':sum(r['y']==0 and r['p']==1 for r in known),'miss_installed':sum(r['y']==1 and r['p']!=1 for r in rows)}
def main():
    normalized='--format-normalized' in sys.argv;suffix='_format_normalized' if normalized else ''
    m=json.loads((O/'data/manifest.json').read_text());truth=json.loads((O/'private/scoring_truth.json').read_text());pred={};digests={}
    for s in range(7):
        p=O/f'results/shard{s}.jsonl';c=json.loads((O/f'results/completion{s}.json').read_text())
        assert c['complete'] and c['shard']==s and c['manifest_sha256']==sha(O/'data/manifest.json') and c['output_sha256']==sha(p)
        rows=[json.loads(x) for x in p.read_text().splitlines()];assert len(rows)==c['queries']
        for r in rows:
            i=r['query_index'];assert i not in pred and i%7==s and r['query']==m['queries'][i];pred[i]=r
        digests[str(s)]=sha(p)
    assert set(pred)==set(range(len(m['queries'])))
    tree=ast.parse((R/'IndustReal/PSR/psr_utils.py').read_text());cats=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='categories' for t in n.targets))
    vectors={};times=collections.defaultdict(float)
    for r in pred.values():
        q=r['query'];key=(q['clip'],q['frame'],q['condition']);v=vectors.setdefault(key,[None]*11);p=parsed_value(r,normalized);times[q['condition']]+=r['seconds']
        if q['target'] is None:
            if isinstance(p,list) and len(p)==11:v[:]=[x if valid(x) else None for x in p]
        else:
            x=p.get('state') if isinstance(p,dict) else None;v[q['target']]=x if valid(x) else None
    scored=[];excluded=[];memory={};transitions=collections.Counter()
    for t in sorted(truth,key=lambda x:(x['clip'],x['frame'])):
        c,f=t['clip'],t['frame'];label=cats[t['gt_class']];ys=[int(x) for x in label] if len(label)==11 and set(label)<={'0','1'} else None
        det=t['detector'];dc=int(det['bb_class']) if det else 0;dl=cats[dc]
        dv=[int(x) for x in dl] if det and float(det['bb_conf'])>=.5 and len(dl)==11 and set(dl)<={'0','1'} else [None]*11
        methods={k:vectors[(c,f,k)] for k in ['joint_single','component_single','component_causal']};methods['detector_reference']=dv
        for method,vec in methods.items():
            mem=memory.setdefault((c,method),[None]*11)
            for j,x in enumerate(vec):
                if valid(x):
                    if valid(mem[j]) and mem[j]!=x:transitions[f'{c}/{method}']+=1
                    mem[j]=x
            if ys is not None:
                for variant,values in [('direct',vec),('causal_memory',mem)]:
                    for j,(y,p) in enumerate(zip(ys,values)):scored.append({'clip':c,'frame':f,'component':j,'method':method,'variant':variant,'y':y,'p':p})
        if ys is None:excluded.append({'clip':c,'frame':f,'gt_class':t['gt_class'],'reason':label})
    grouped={}
    for method in ['joint_single','component_single','component_causal','detector_reference']:
        for variant in ['direct','causal_memory']:
            rows=[r for r in scored if r['method']==method and r['variant']==variant]
            grouped[f'{method}/{variant}']={'pooled':metrics(rows),'per_clip':{c:metrics([r for r in rows if r['clip']==c]) for c in sorted({r['clip'] for r in rows})},'per_component':{str(j):metrics([r for r in rows if r['component']==j]) for j in range(11)}}
    audit={'passed':True,'queries':len(pred),'sampled_frames':len(truth),'source_manifest_sha256':sha(O/'data/manifest.json'),'shard_sha256':digests,'scorer_sha256':sha(Path(__file__)),'labels_not_on_inference_host':True}
    (O/f'independent_audit{suffix}.json').write_text(json.dumps(audit,indent=2)+'\n')
    result={'complete':True,'created_at':datetime.datetime.now().astimezone().isoformat(),'audit':audit,'all_conditions':grouped,'excluded_nonbinary_frames':excluded,'prediction_transitions_descriptive_only':dict(transitions),'aggregate_query_seconds':dict(times),'scope':'Two partial convenience-source RGB slices. Component bit truth from supplied ASD GT, not visibility, original15nodeFSM alarm metrics, or independent normal-hour evidence. Detector reference is supplied pretrained detector, not retrained same-data fair capacity baseline.'}
    result['parsing_rule']='JSON code fence removal only; post-inference implementation diagnostic, primary strict result retained' if normalized else 'strict JSON primary'
    (O/f'results_summary{suffix}.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# IndustReal视觉状态与因果记忆补充实验','',f'已审计{len(pred)}条查询、{len(truth)}个采样帧。非二进制GT帧{len(excluded)}个，单列保留。','', '|条件|直接状态准确率（Unknown算错）|因果记忆准确率|直接覆盖率|','|---|---:|---:|---:|']
    for method in ['joint_single','component_single','component_causal','detector_reference']:
        a=grouped[f'{method}/direct']['pooled'];b=grouped[f'{method}/causal_memory']['pooled']
        fmt=lambda x:'NA' if x is None else f'{100*x:.2f}%'
        lines.append(f"|{method}|{fmt(a['accuracy_unknown_as_wrong'])}|{fmt(b['accuracy_unknown_as_wrong'])}|{fmt(a['coverage'])}|")
    lines+=['','全部条件与每段/每部件结果见results_summary.json。此实验评估组件安装状态及最小因果记忆，不等于原15步FSM完整报警，不代表完整官方测试集。官方检测器为现成参考，其训练数据与VLM不同。不得据此声称VLM已胜过所有基线。']
    lines+=['',result['parsing_rule']]
    (O/f'report{suffix}.md').write_text('\n'.join(lines)+'\n');print(json.dumps({k:v['pooled'] for k,v in grouped.items()}),flush=True)
if __name__=='__main__':main()
