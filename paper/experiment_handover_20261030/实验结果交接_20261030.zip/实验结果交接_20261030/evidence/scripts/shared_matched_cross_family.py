"""CPU-only, complete exploratory cross-family comparison; never select runs."""
import csv
import hashlib
import io
import itertools
import json
import math
from pathlib import Path

import numpy as np

R = Path(__file__).resolve().parents[1]
GROUPS = ('M0', 'M1', 'M2', 'M3')
SEEDS = (42, 43, 44)
TASKS = ('ATP', 'Full', 'ROI')
SCHEDULES = ('primary30', 'prefix30', 'cosine4')


def read(path):
    return json.loads(path.read_text())


def exact_p(wins, losses):
    n = wins + losses
    return min(1., 2 * sum(math.comb(n, k) for k in range(min(wins, losses) + 1)) / 2**n) if n else 1.


def main():
    required = {
        'vlm': R / 'results/E1-D_matched1gpu_three_run_analysis_20261029.json',
        'primary': R / 'results/E2-D_shared_resnet_audit.json',
        'short': R / 'results/E2-E_four_epoch_resnet_audit_20261029.json',
    }
    missing = [str(p.relative_to(R)) for p in required.values() if not p.exists()]
    if missing:
        print(json.dumps({'status': 'waiting_complete_audits', 'missing': missing}))
        return
    vlm, primary, short = [read(required[k]) for k in ('vlm', 'primary', 'short')]
    assert vlm['complete'] and len(vlm['all']) == 12
    assert primary['audited_runs'] == 12 and len(primary['all']) == 12
    assert short['passed'] and short['audited_models'] == 24 and len(short['all']) == 24
    inputs = {str(p.relative_to(R)): hashlib.sha256(p.read_bytes()).hexdigest() for p in required.values()}
    for p in [R / '一致配置跨家族完整比较规则_20261029.md', Path(__file__).resolve()]:
        inputs[str(p.relative_to(R))] = hashlib.sha256(p.read_bytes()).hexdigest()
    manifest = R / 'cloud_mirror/E2-D_JointResNet_s42_20261028/source_manifest.json'
    expected = {(r['source_id'], r['view']): r for r in read(manifest) if r['split'] == 'test'}
    assert len(expected) == 1115
    inputs[str(manifest.relative_to(R))] = hashlib.sha256(manifest.read_bytes()).hexdigest()

    def bank(path, completion, family):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == completion['predictions_sha256'], str(path)
        inputs[str(path.relative_to(R))] = digest
        result = {}
        for r in [json.loads(x) for x in raw.splitlines()]:
            k = (r['source_id'], r['view'])
            assert k in expected and k not in result, (path, k)
            source = expected[k]
            assert r['gt'] == source['gt'] and r['task'] == source['task']
            if family == 'VLM':
                assert r['image_sha256'] == source['hash']
                try:
                    pred = json.loads(r['raw_output'])
                    valid = isinstance(pred, dict) and set(pred) == set(r['gt']) and all(isinstance(v, str) for v in pred.values())
                    if valid:
                        valid = (pred['action'] in ('Place', 'Install', 'Insert', 'Tighten') and bool(pred['tool'].strip()) and bool(pred['part'].strip())) if r['task'] == 'ATP' else (pred['verification'] in ('Finish', 'Unfinish') and bool(pred['part'].strip()))
                except (ValueError, TypeError):
                    valid, pred = False, {}
                assert valid == r['strict_valid']
            else:
                pred, valid = r['prediction'], True
                assert set(pred) == set(r['gt'])
                assert r['checkpoint_sha256'] == completion['checkpoint_sha256']
            result[k] = bool(valid and (pred == r['gt'] if r['task'] == 'ATP' else pred['verification'] == r['gt']['verification']))
        assert set(result) == set(expected)
        return result

    banks = {}
    for a in vlm['all']:
        assert a['training']['world_size'] == 1
        key = ('VLM', a['seed'], a['group'])
        assert key not in banks
        banks[key] = bank(R / 'cloud_mirror' / a['project'] / 'results' / a['group'] / 'predictions.jsonl', a['completion'], 'VLM')
    for schedule, audit in [('primary30', primary), ('short', short)]:
        for a in audit['all']:
            sc = a['schedule'] if schedule == 'short' else schedule
            project = a['project'] if schedule == 'short' else f"E2-D_JointResNet_s{a['seed']}_20261028"
            key = (sc, a['seed'], a['group'])
            assert key not in banks
            banks[key] = bank(R / 'cloud_mirror' / project / 'runs' / a['group'] / 'predictions.jsonl', a['completion'], 'ResNet50')
    assert set(banks) == set(itertools.product(('VLM',) + SCHEDULES, SEEDS, GROUPS))
    rng = np.random.default_rng(20261029)
    contrasts, summaries = [], []
    for task in TASKS:
        keys = sorted(k for k, r in expected.items() if (r['task'] == 'ATP' if task == 'ATP' else r['task'] == 'verification' and k[1] == task))
        n = len(keys)
        assert n == (545 if task == 'ATP' else 285)
        indices = rng.integers(0, n, size=(10000, n))
        for schedule, group in itertools.product(SCHEDULES, GROUPS):
            deltas, va, ra = [], [], []
            for seed in SEEDS:
                v = np.array([banks['VLM', seed, group][k] for k in keys], dtype=int)
                r = np.array([banks[schedule, seed, group][k] for k in keys], dtype=int)
                delta = v - r
                vw, rw = int(((v == 1) & (r == 0)).sum()), int(((v == 0) & (r == 1)).sum())
                contrasts.append({'schedule': schedule, 'group': group, 'task': task, 'seed': seed, 'n_sources': n, 'VLM_correct': int(v.sum()), 'ResNet50_correct': int(r.sum()), 'VLM_only_correct': vw, 'ResNet50_only_correct': rw, 'difference_VLM_minus_ResNet50': float(delta.mean()), 'p_exact_conditional_frames': exact_p(vw, rw), 'unsupervised_state_diagnostic': group == 'M0' and task != 'ATP'})
                deltas.append(delta)
                va.append(float(v.mean()))
                ra.append(float(r.mean()))
            avg = np.mean(deltas, axis=0)
            summaries.append({'schedule': schedule, 'group': group, 'task': task, 'seeds': list(SEEDS), 'VLM_values': va, 'ResNet50_values': ra, 'VLM_mean': float(np.mean(va)), 'VLM_sd': float(np.std(va, ddof=1)), 'ResNet50_mean': float(np.mean(ra)), 'ResNet50_sd': float(np.std(ra, ddof=1)), 'fixed_three_model_mean_difference': float(avg.mean()), 'conditional_source_bootstrap95': np.quantile(avg[indices].mean(1), [.025, .975]).tolist(), 'unsupervised_state_diagnostic': group == 'M0' and task != 'ATP'})
    assert len(contrasts) == 108 and len(summaries) == 36
    previous = 0.
    for rank, i in enumerate(sorted(range(108), key=lambda i: contrasts[i]['p_exact_conditional_frames'])):
        previous = min(1., max(previous, (108 - rank) * contrasts[i]['p_exact_conditional_frames']))
        contrasts[i]['p_holm_all108_cross_family'] = previous
    scope = ('Exploratory supplement with prior core/primary-baseline results known. All matched world1 VLM seeds42/43/44, all groups/tasks/views and all three ResNet schedules. Primary30 remains the strong baseline. M0 state heads are unsupervised diagnostics. Same seed indices do not imply shared initialization across architectures. Different pretraining/optimizers/resolutions/FLOPs: not an equal-compute architecture test. Source exchangeability is unverified; intervals condition on the three fixed models, not training randomness or independent recordings. All108 tests retained; Holm108 is this analysis family only, not a global adjustment over every study. No noon snapshot or Word overwrite.')
    out = {'complete': True, 'protocol': '一致配置跨家族完整比较规则_20261029.md', 'inputs': inputs, 'scope': scope, 'summaries': summaries, 'all108_contrasts': contrasts}
    base = R / 'results/E1-D_matched_cross_family_20261029'
    base.with_suffix('.json').write_text(json.dumps(out, indent=2) + '\n')
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=list(contrasts[0]))
    writer.writeheader()
    writer.writerows(contrasts)
    base.with_suffix('.csv').write_text(buf.getvalue())
    md = ['# 一致单卡三种子与共享ResNet完整比较', '', scope, '', '|日程|组|任务|VLM %|ResNet50 %|差值pp|固定模型源图条件性95%区间pp|', '|---|---|---|---:|---:|---:|---:|']
    for a in summaries:
        lo, hi = a['conditional_source_bootstrap95']
        label = a['task'] + ('（未监督诊断）' if a['unsupervised_state_diagnostic'] else '')
        md.append(f"|{a['schedule']}|{a['group']}|{label}|{100*a['VLM_mean']:.2f} ± {100*a['VLM_sd']:.2f}|{100*a['ResNet50_mean']:.2f} ± {100*a['ResNet50_sd']:.2f}|{100*a['fixed_three_model_mean_difference']:.2f}|[{100*lo:.2f}, {100*hi:.2f}]|")
    md += ['', '全部108项逐种子比较、正确数、互有胜负数和Holm108结果见同名CSV/JSON。']
    base.with_suffix('.md').write_text('\n'.join(md) + '\n')
    print(json.dumps({'complete': True, 'models': 48, 'contrasts': 108, 'summary_rows': 36}))


if __name__ == '__main__':
    main()
