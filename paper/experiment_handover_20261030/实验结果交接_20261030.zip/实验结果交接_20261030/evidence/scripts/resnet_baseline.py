"""Predeclared ResNet18 baseline; final epoch only, no validation selection."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import hashlib,json,random,time,socket,subprocess
from pathlib import Path
import numpy as np
import torch,torchvision
from PIL import Image
from torchvision import transforms as T
ROOT=Path(__file__).resolve().parents[1]
DATA=Path('/home/caiyunchen/jms-revision/E1-AB_20261027')
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def seed(s):random.seed(s);np.random.seed(s);torch.manual_seed(s);torch.cuda.manual_seed_all(s)
torch.set_num_threads(8);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
transform=T.Compose([T.Resize((224,224),interpolation=T.InterpolationMode.BILINEAR,antialias=True),T.ToTensor(),T.Normalize([.485,.456,.406],[.229,.224,.225])])
class Frames(torch.utils.data.Dataset):
 def __init__(self,examples):self.examples=examples
 def __len__(self):return len(self.examples)
 def __getitem__(self,i):
  row,view=self.examples[i]
  with Image.open(DATA/row['full_path' if view=='Full' else 'roi_path']) as im:x=transform(im.convert('RGB'))
  return x,int(row['gt_status']=='Finish'),row['source_id'],view
def main():
 ROOT.joinpath('runs').mkdir(exist_ok=True)
 status=ROOT/'status.json'
 if status.exists():raise RuntimeError('Refuse prior baseline state; inspect before retry')
 started=time.time();save(status,{'status':'checking','started_at':started,'hostname':socket.gethostname()})
 lock=read(DATA/'config/runtime_lock.json')
 for rel,h in lock['protected_file_hashes'].items():assert sha(DATA/rel)==h,rel
 rows=read(DATA/'data/source_manifest.json');rois={r['source_id']:r for r in read(DATA/'data/roi_manifest.json')}
 for r in rows:
  assert sha(DATA/r['full_path'])==r['full_sha256']
  assert sha(DATA/r['roi_path'])==rois[r['source_id']]['roi_sha256']
 assert len(rows)==497 and sum(r['split']=='train' for r in rows)==212
 weights=ROOT/'weights/resnet18-f37072fd.pth';wh=sha(weights);assert wh.startswith('f37072fd')
 protocol=read(ROOT/'protocol.json')
 save(ROOT/'runtime.json',{'torch':torch.__version__,'torchvision':torchvision.__version__,'weights_sha256':wh,'protocol_sha256':sha(ROOT/'protocol.json'),'device':torch.cuda.get_device_name(),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).strip(),'host':socket.gethostname(),'transform':repr(transform)})
 completed=[]
 for s in protocol['seeds']:
  for group in protocol['groups']:
   seed(s);dest=ROOT/'runs'/f'{group}_s{s}';dest.mkdir()
   state={'status':'training','active':f'{group}_s{s}','started_at':started,'completed':completed};save(status,state)
   train=[]
   for r in rows:
    if r['split']!='train':continue
    views={'full':['Full'],'roi':['ROI'],'mixed':['Full','ROI'],'full_repeat2':['Full','Full']}[group]
    train.extend((r,v) for v in views)
   generator=torch.Generator().manual_seed(s)
   loader=torch.utils.data.DataLoader(Frames(train),batch_size=32,shuffle=True,generator=generator,num_workers=0,drop_last=False)
   model=torchvision.models.resnet18(weights=None);model.load_state_dict(torch.load(weights,map_location='cpu',weights_only=True));model.fc=torch.nn.Linear(model.fc.in_features,2);model.cuda()
   opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=.01);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30)
   steps=0;t=time.monotonic();torch.cuda.reset_peak_memory_stats()
   for epoch in range(30):
    model.train();loss_sum=0;n=0
    for x,y,ids,views in loader:
     x=x.cuda();y=y.cuda();opt.zero_grad(set_to_none=True);out=model(x);loss=torch.nn.functional.cross_entropy(out,y)
     if not torch.isfinite(loss):raise RuntimeError('nonfinite loss')
     loss.backward();opt.step();steps+=1;loss_sum+=float(loss.detach())*len(y);n+=len(y)
    assert n==len(train)
    with (dest/'epochs.jsonl').open('a') as f:f.write(json.dumps({'epoch':epoch+1,'n':n,'loss':loss_sum/n,'lr_used':opt.param_groups[0]['lr'],'steps':steps})+'\n')
    scheduler.step()
   torch.cuda.synchronize();train_s=time.monotonic()-t;torch.save(model.state_dict(),dest/'final.pt');checkpoint=sha(dest/'final.pt')
   model.eval();test=[(r,v) for r in rows if r['split']=='test' for v in ('Full','ROI')];pred=[]
   for x,y,ids,views in torch.utils.data.DataLoader(Frames(test),batch_size=32,shuffle=False,num_workers=0):
    with torch.inference_mode():probs=model(x.cuda()).float().softmax(-1).cpu()
    for sid,v,gt,p in zip(ids,views,y.tolist(),probs.tolist()):pred.append({'source_id':sid,'view':v,'gt':gt,'prob_unfinish':p[0],'prob_finish':p[1],'prediction':int(p[1]>p[0]),'checkpoint_sha256':checkpoint})
   assert len(pred)==570 and len({(r['source_id'],r['view']) for r in pred})==570
   with (dest/'predictions.jsonl').open('w') as f:
    for r in pred:f.write(json.dumps(r)+'\n')
   metrics={}
   for view in ('Full','ROI'):
    rs=[r for r in pred if r['view']==view];tp=sum(r['gt']==1 and r['prediction']==1 for r in rs);fp=sum(r['gt']==0 and r['prediction']==1 for r in rs);fn=sum(r['gt']==1 and r['prediction']==0 for r in rs);tn=sum(r['gt']==0 and r['prediction']==0 for r in rs)
    assert tp+fn==141 and fp+tn==144
    metrics[view]={'TP':tp,'FP':fp,'FN':fn,'TN':tn,'accuracy':(tp+tn)/285,'FPR':fp/144,'recall':tp/141,'unfinish_accuracy':tn/144}
   save(dest/'completion.json',{'completed':True,'seed':s,'group':group,'training_examples':len(train)*30,'updates':steps,'epochs':30,'selection':'fixed final epoch30','training_seconds':train_s,'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'checkpoint_sha256':checkpoint,'predictions_sha256':sha(dest/'predictions.jsonl'),'metrics':metrics})
   completed.append(f'{group}_s{s}');del model,opt,scheduler;torch.cuda.empty_cache();print(completed[-1],metrics,flush=True)
 save(status,{'status':'completed','completed':completed,'started_at':started,'finished_at':time.time()})
if __name__=='__main__':main()
