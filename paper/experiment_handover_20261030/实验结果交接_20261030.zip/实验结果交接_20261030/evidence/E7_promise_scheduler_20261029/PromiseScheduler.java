package fsmcli;

// Revision adapter around the immutable Liu Binghong/coauthor Java core.
// Scheduling, request binding and hard admission below are NEW, not legacy-core claims.
import com.fasterxml.jackson.databind.*;
import nusri.fyp.demo.state_machine.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;

public final class PromiseScheduler {
    static final ObjectMapper J=SopLoader.JSON;
    final SopLoader sop;
    StateMachine core;
    final Set<Integer> admitted=new LinkedHashSet<>();
    final Set<String> active=new LinkedHashSet<>();
    final Set<String> consumed=new HashSet<>();
    int epoch=0, serial=0;
    double last=-1;
    Map<String,Object> request;
    PromiseScheduler(SopLoader s){sop=s;reset();}
    static Map<String,Object> map(Object... a){return FsmCli.map(a);}
    boolean eligible(int id){for(JsonNode p:sop.nodes.get(id).path("parents"))if(!admitted.contains(p.asInt()))return false;return true;}
    void reset(){core=sop.machine(true,true);admitted.clear();active.clear();consumed.clear();last=-1;serial=0;epoch++;schedule();}
    void schedule(){
        for(Node n:core.getNodes())if(!admitted.contains(n.getId())&&eligible(n.getId())&&n.isVerificationRequired()&&n.isCompletionEvidenceReady(core.getQuotaConfig())){
            request=map("request_id",epoch+":"+(++serial),"mode","Verification","node_id",n.getId(),"condition",n.getVerificationCondition());return;
        }
        List<Integer> ready=new ArrayList<>();for(int id:sop.nodes.keySet())if(!admitted.contains(id)&&eligible(id))ready.add(id);
        request=map("request_id",epoch+":"+(++serial),"mode",admitted.size()==sop.nodes.size()?"Complete":"General","eligible_nodes",ready);
    }
    Map<String,Object> snapshot(){
        List<Map<String,Object>> nodes=new ArrayList<>();
        for(Node n:core.getNodes()){
            double t=n.T(core.getQuotaConfig());if(!Double.isFinite(t))throw new IllegalStateException("nonfinite core state");
            nodes.add(map("id",n.getId(),"evidence_seconds",t,"core_done",n.isDone(core.getQuotaConfig()),"verified",n.isVerificationConfirmed(),"admitted",admitted.contains(n.getId())));
        }
        return map("request",request,"admitted",new ArrayList<>(admitted),"nodes",nodes,"active_alarms",new ArrayList<>(active));
    }
    Map<String,Object> consume(JsonNode r){
        if(r.has("gt")||r.has("ground_truth"))throw new IllegalArgumentException("GT forbidden");
        Map<String,Object> before=request;
        String rid=r.path("request_id").asText();
        String reject=null;
        double time=r.path("timestamp_ms").asDouble(Double.NaN),conf=r.path("confidence").asDouble(Double.NaN);
        if(consumed.contains(rid))reject="duplicate_response";
        else if(!Objects.equals(rid,request.get("request_id")))reject="stale_or_unknown_request";
        else if(!Double.isFinite(time)||time<=last||time<0)reject="invalid_time";
        else if(!Double.isFinite(conf)||conf<0||conf>1)reject="invalid_confidence";
        else if(!Objects.equals(r.path("mode").asText(),request.get("mode")))reject="wrong_mode";
        else if(r.path("mode").asText().equals("Verification")&&(!Objects.equals(r.path("target_condition").asText(),request.get("condition"))||r.path("node_id").asInt()!=((Number)request.get("node_id")).intValue()))reject="wrong_target";
        else if(r.path("mode").asText().equals("Verification")&&!Set.of("finish","unfinish","unknown").contains(r.path("verification_label").asText()))reject="invalid_label";
        else if(r.path("mode").asText().equals("General")&&(!r.path("action_key").isTextual()||r.path("action_key").asText().isBlank()))reject="invalid_action";
        if(reject!=null)return map("accepted",false,"reason",reject,"before",before,"state",snapshot());
        Set<Integer> eligibleBefore=new HashSet<>();for(int id:sop.nodes.keySet())if(eligible(id))eligibleBefore.add(id);
        Set<Integer> touched=new HashSet<>();
        if(r.path("mode").asText().equals("General")){
            ActionObservation a=new ActionObservation();a.setActionAndObject(r.path("action_key").asText());a.setProbability(conf);
            for(Node n:core.getNodesByS(a.s()))touched.add(n.getId());
            core.updateStateProbability(List.of(a),time);
        }else{
            VerificationObservation v=new VerificationObservation();v.setCondition(r.path("target_condition").asText());v.setVerificationLabel(r.path("verification_label").asText());v.setVerified(r.path("verification_label").asText().equals("finish"));v.setProbability(conf);
            touched.add(r.path("node_id").asInt());core.updateStateProbability(List.of(v),time);
        }
        Set<Integer> released=new LinkedHashSet<>();
        for(Node n:core.getNodes())if(touched.contains(n.getId())&&eligibleBefore.contains(n.getId())&&n.isDone(core.getQuotaConfig())&&admitted.add(n.getId()))released.add(n.getId());
        Set<String> alarms=new LinkedHashSet<>();
        for(Node n:core.getNodes()){
            if(core.isUnfinishedConditionAlarm(n))alarms.add("unfinished:"+n.getId());
            if(n.E(core.getQuotaConfig())>=sop.source.path("alarm_policy").path("order_threshold").asDouble())alarms.add("core_wrong_order:"+n.getId());
            if(n.D(core.getQuotaConfig())>=sop.source.path("alarm_policy").path("timeout_threshold").asDouble())alarms.add("timeout:"+n.getId());
        }
        for(int id:touched)if(!eligibleBefore.contains(id)&&!admitted.contains(id))alarms.add("adapter_dependency_violation:"+id);
        List<String> onset=new ArrayList<>(),resolved=new ArrayList<>();
        for(String a:alarms)if(!active.contains(a))onset.add(a);
        for(String a:active)if(!alarms.contains(a))resolved.add(a);
        active.clear();active.addAll(alarms);last=time;consumed.add(rid);schedule();
        return map("accepted",true,"before",before,"released",released,"alarm_onset",onset,"alarm_resolved",resolved,"state",snapshot());
    }
    public static void main(String[] args)throws Exception{
        SopLoader s=new SopLoader(Path.of(args[0]));if(!s.errors.isEmpty()||!s.pending.isEmpty())throw new IllegalArgumentException(s.report().toString());
        PromiseScheduler runner=new PromiseScheduler(s);
        try(BufferedReader in=Files.newBufferedReader(Path.of(args[1]));BufferedWriter out=Files.newBufferedWriter(Path.of(args[2]),StandardOpenOption.CREATE_NEW)){
            for(String line;(line=in.readLine())!=null;){
                long start=System.nanoTime();JsonNode command=J.readTree(line);Map<String,Object> result;
                if(command.path("op").asText().equals("reset")){runner.reset();result=map("reset",true,"state",runner.snapshot());}
                else{
                    JsonNode response=command.path("response").deepCopy();
                    // Fixture/client binds current request, not an offline truth-dependent target.
                    if(command.path("bind_current_request").asBoolean()){
                        ((com.fasterxml.jackson.databind.node.ObjectNode)response).put("request_id",runner.request.get("request_id").toString());
                    }
                    result=runner.consume(response);
                }
                result.put("case_id",command.path("case_id").asText());
                String serialized=J.writeValueAsString(result);long elapsed=System.nanoTime()-start;
                out.write(J.writeValueAsString(map("result",J.readTree(serialized),"cpu_chain_ns",elapsed)));out.newLine();
            }
        }
    }
}
