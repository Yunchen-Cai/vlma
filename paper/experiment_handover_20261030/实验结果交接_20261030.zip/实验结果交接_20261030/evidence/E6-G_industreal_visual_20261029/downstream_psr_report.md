# 稀疏视觉验证→官方PSR下游结果

全部48次真实回放完成；下表是保留检测器置信度的主对照，全部控制及含错误事件标签敏感性保留于JSON。

|录像|视觉输入|PSR|官方TP/FP/FN|官方F1|延迟秒|
|---|---|---|---|---:|---:|
|03_assy_0_1|detector_reference|naive|9/0/0|1.0000|9.10|
|03_assy_0_1|detector_reference|confidence|9/0/0|1.0000|12.50|
|03_assy_0_1|detector_reference|expected|9/0/0|1.0000|12.50|
|03_assy_0_1|joint_single|naive|9/0/0|1.0000|9.10|
|03_assy_0_1|joint_single|confidence|9/0/0|1.0000|12.50|
|03_assy_0_1|joint_single|expected|9/0/0|1.0000|12.50|
|03_assy_0_1|component_single|naive|9/0/0|1.0000|9.10|
|03_assy_0_1|component_single|confidence|9/0/0|1.0000|12.50|
|03_assy_0_1|component_single|expected|9/0/0|1.0000|12.50|
|03_assy_0_1|component_causal|naive|9/0/0|1.0000|9.10|
|03_assy_0_1|component_causal|confidence|9/0/0|1.0000|12.50|
|03_assy_0_1|component_causal|expected|9/0/0|1.0000|12.50|
|03_assy_1_3|detector_reference|naive|3/3/5|0.4286|14.30|
|03_assy_1_3|detector_reference|confidence|3/3/5|0.4286|20.80|
|03_assy_1_3|detector_reference|expected|3/3/5|0.4286|20.80|
|03_assy_1_3|joint_single|naive|3/3/5|0.4286|14.30|
|03_assy_1_3|joint_single|confidence|3/3/5|0.4286|20.80|
|03_assy_1_3|joint_single|expected|3/3/5|0.4286|20.80|
|03_assy_1_3|component_single|naive|3/3/5|0.4286|14.30|
|03_assy_1_3|component_single|confidence|3/3/5|0.4286|20.80|
|03_assy_1_3|component_single|expected|3/3/5|0.4286|20.80|
|03_assy_1_3|component_causal|naive|3/3/5|0.4286|14.30|
|03_assy_1_3|component_causal|confidence|3/3/5|0.4286|20.80|
|03_assy_1_3|component_causal|expected|3/3/5|0.4286|20.80|

官方指标为步骤识别，含提前预测惩罚，不能重命名为完整错误报警指标。方法/条件全部报告，不能只选提高的一列。
