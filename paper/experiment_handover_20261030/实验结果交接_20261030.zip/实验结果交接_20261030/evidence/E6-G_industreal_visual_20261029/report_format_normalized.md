# IndustReal视觉状态与因果记忆补充实验

已审计2829条查询、123个采样帧。非二进制GT帧108个，单列保留。

|条件|直接状态准确率（Unknown算错）|因果记忆准确率|直接覆盖率|
|---|---:|---:|---:|
|joint_single|41.21%|56.36%|73.33%|
|component_single|41.21%|60.61%|73.94%|
|component_causal|0.00%|0.00%|0.00%|
|detector_reference|40.00%|100.00%|40.00%|

全部条件与每段/每部件结果见results_summary.json。此实验评估组件安装状态及最小因果记忆，不等于原15步FSM完整报警，不代表完整官方测试集。官方检测器为现成参考，其训练数据与VLM不同。不得据此声称VLM已胜过所有基线。

JSON code fence removal only; post-inference implementation diagnostic, primary strict result retained
